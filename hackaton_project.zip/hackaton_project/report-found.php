<?php
session_start();
require_once('includes/config.php');
require_once('includes/auth.php');
require_once('includes/functions.php');
require_once('includes/upload.php');
// Redirect to login if not authenticated

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$error = '';
$success = false;

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_name = $_POST['item_name'] ?? '';
    $category = $_POST['category'] ?? '';
    $date_found = $_POST['date_found'] ?? '';
    $location = $_POST['location'] ?? '';
    $description = $_POST['description'] ?? '';
    $turned_in = isset($_POST['turned_in']) ? 1 : 0;
    $turned_in_location = $_POST['turned_in_location'] ?? '';
    
    // Handle file upload
    $item_photo = null;
    if (isset($_FILES['item_photo']) && $_FILES['item_photo']['error'] === UPLOAD_ERR_OK) {
        $upload_result = uploadItemPhoto($_FILES['item_photo']);
        if ($upload_result['success']) {
            $item_photo = $upload_result['filename'];
        } else {
            $error = $upload_result['message'];
        }
    }
    
    // Validation
    if (empty($item_name) || empty($category) || empty($date_found) || empty($location)) {
        $error = 'Please fill in all required fields.';
    } elseif ($turned_in && empty($turned_in_location)) {
        $error = 'Please specify where you turned in the item.';
    } elseif (empty($error)) {
        // Save report to database
        $result = saveReportFound($_SESSION['user_id'], $item_name, $category, $date_found, $location, $description, $item_photo, $turned_in, $turned_in_location);
        
        if ($result['success']) {
            $success = true;
            $report_id = $result['report_id'];
            
            // Check for potential matches
            findPotentialMatches($report_id, 'found');
        } else {
            $error = $result['message'];
        }
    }
}

// Get categories
$categories = getItemCategories();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('includes/head.php'); ?>
    <title>Report Found Item - Campus Finder</title>
</head>
<body>
    <?php include('includes/header.php'); ?>
    
    <main class="container mx-auto px-4 py-8">
        <div class="max-w-2xl mx-auto">
            <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                <h2 class="text-2xl font-bold mb-6">Report a Found Item</h2>
                
                <?php if ($error): ?>
                    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                        <p><?php echo htmlspecialchars($error); ?></p>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
                        <p>Your found item report has been submitted successfully.</p>
                        <p class="mt-2">We'll notify you if someone reports losing a similar item.</p>
                        <div class="mt-4">
                            <a href="index.php" class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition duration-300">Return to Dashboard</a>
                            <a href="report-found.php" class="inline-block bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded-md transition duration-300 ml-2">Report Another Item</a>
                        </div>
                    </div>
                <?php else: ?>
                    <form method="POST" action="report-found.php" enctype="multipart/form-data">
                        <div class="mb-4">
                            <label for="item_name" class="block text-gray-700 text-sm font-bold mb-2">Item Name *</label>
                            <input type="text" id="item_name" name="item_name" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500" required>
                        </div>
                        
                        <div class="mb-4">
                            <label for="category" class="block text-gray-700 text-sm font-bold mb-2">Category *</label>
                            <select id="category" name="category" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500" required>
                                <option value="">Select a category</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo htmlspecialchars($cat['id']); ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-4">
                            <label for="date_found" class="block text-gray-700 text-sm font-bold mb-2">Date Found *</label>
                            <input type="date" id="date_found" name="date_found" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500" required>
                        </div>
                        
                        <div class="mb-4">
                            <label for="location" class="block text-gray-700 text-sm font-bold mb-2">Location Found *</label>
                            <select id="location" name="location" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500" required>
                                <option value="">Select location</option>
                                <option value="library">Library</option>
                                <option value="student_center">Student Center</option>
                                <option value="dining_hall">Dining Hall</option>
                                <option value="gym">Gymnasium</option>
                                <option value="dorm">Dormitory</option>
                                <option value="classroom">Classroom</option>
                                <option value="outdoor">Outdoor Areas</option>
                                <option value="parking">Parking Lot</option>
                                <option value="other">Other (specify in description)</option>
                            </select>
                        </div>
                        
                        <div class="mb-4">
                            <label for="description" class="block text-gray-700 text-sm font-bold mb-2">Description</label>
                            <textarea id="description" name="description" rows="4" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500" placeholder="Please provide a detailed description of the item (color, brand, identifying features, etc.)"></textarea>
                        </div>
                        
                        <div class="mb-4">
                            <label for="item_photo" class="block text-gray-700 text-sm font-bold mb-2">Upload Photo</label>
                            <input type="file" id="item_photo" name="item_photo" accept="image/*" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500">
                            <p class="text-sm text-gray-500 mt-1">Optional, but helpful for identification. Max size: 5MB</p>
                        </div>
                        
                        <div class="mb-4">
                            <div class="flex items-center">
                                <input type="checkbox" id="turned_in" name="turned_in" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                <label for="turned_in" class="ml-2 block text-gray-700 font-medium">I've turned this item in to a campus authority</label>
                            </div>
                        </div>
                        
                        <div id="turned_in_location_container" class="mb-6 hidden">
                            <label for="turned_in_location" class="block text-gray-700 text-sm font-bold mb-2">Where did you turn it in? *</label>
                            <select id="turned_in_location" name="turned_in_location" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500">
                                <option value="">Select location</option>
                                <option value="campus_security">Campus Security Office</option>
                                <option value="student_services">Student Services Center</option>
                                <option value="residence_hall">Residence Hall Front Desk</option>
                                <option value="library_desk">Library Information Desk</option>
                                <option value="department_office">Department Office</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        
                        <div class="flex items-center justify-end">
                            <button type="submit" class="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-6 rounded-md focus:outline-none focus:shadow-outline transition duration-300">
                                Submit Report
                            </button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </main>
    
    <?php include('includes/footer.php'); ?>
    <script src="js/app.js"></script>
    <script>
        // Show/hide turned in location based on checkbox
        document.getElementById('turned_in').addEventListener('change', function() {
            const container = document.getElementById('turned_in_location_container');
            if (this.checked) {
                container.classList.remove('hidden');
            } else {
                container.classList.add('hidden');
            }
        });
    </script>
</body>
</html>