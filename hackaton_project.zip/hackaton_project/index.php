<?php
session_start();
//require_once('includes/config.php');
require_once('includes/auth.php');





require_once('includes/auth.php');

$userName = '';

// Check if logged in and retrieve user data
if (isset($_SESSION['user_id'])) {
    $userData = getUserData($_SESSION['user_id']);
    if ($userData && is_array($userData)) {
        $userName = $userData['name'];
    }
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('includes/head.php'); ?>
    <title>LostLink - Lost & Found System</title>
</head>
<body>
    <?php include('includes/header.php'); ?>
    
    <main class="container mx-auto px-4 py-8">
        <section class="mb-10">
           <h2 class="text-2xl font-bold mb-4">
    Welcome<?php echo $userName ? ', ' . htmlspecialchars($userName) : ''; ?>
</h2>

                <p class="text-gray-700 mb-6">Use LostLink to report lost or found items and help reconnect people with their belongings.</p>
                
                <div class="grid md:grid-cols-2 gap-4">
                    <div class="bg-blue-50 rounded-lg p-6 border border-blue-200 hover:shadow-md transition duration-300">
                        <h3 class="text-xl font-semibold mb-3 text-blue-800">I Lost Something</h3>
                        <p class="mb-4 text-gray-700">Submit a detailed report about your lost item and get notified if someone finds it.</p>
                        <a href="report-lost.php" class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition duration-300">Report Lost Item</a>
                    </div>
                    
                    <div class="bg-green-50 rounded-lg p-6 border border-green-200 hover:shadow-md transition duration-300">
                        <h3 class="text-xl font-semibold mb-3 text-green-800">I Found Something</h3>
                        <p class="mb-4 text-gray-700">Report an item you've found on campus to help return it to its owner.</p>
                        <a href="report-found.php" class="inline-block bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-md transition duration-300">Report Found Item</a>
                    </div>
                </div>
            </div>
        </section>
        
       <?php if (isset($_SESSION['user_id'])): ?>
    <section class="mb-10">
        <h2 class="text-2xl font-bold mb-4">Recent Activity</h2>
        <div class="bg-white rounded-lg shadow-md p-6">
            <?php include('components/recent-items.php'); ?>
        </div>
    </section>

    <section class="grid md:grid-cols-2 gap-6">
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-2xl font-bold mb-4">Your Reports</h2>
            <?php include('components/user-reports.php'); ?>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-2xl font-bold mb-4">Potential Matches</h2>
            <?php include('components/potential-matches.php'); ?>
        </div>
    </section>
<?php endif; ?>

    </main>
    
    <?php include('includes/footer.php'); ?>
    <script src="js/app.js"></script>
</body>
</html>