<?php
session_start();
require_once('includes/config.php');
require_once('includes/auth.php');
require_once('includes/functions.php');

// Redirect if not logged in
if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user = getUserData($user_id);
$items = getUserItems($user_id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('includes/head.php'); ?>
    <title>My Profile - LostLink</title>
</head>
<body>
    <?php include('includes/header.php'); ?>

    <main class="container mx-auto px-4 py-8">
        <div class="max-w-3xl mx-auto">
            <div class="bg-white shadow rounded-lg p-6 mb-6">
                <h2 class="text-2xl font-bold mb-4">My Profile</h2>
                <div class="grid md:grid-cols-2 gap-4">
                    <div>
                        <p><span class="font-semibold text-gray-700">Name:</span> <?php echo htmlspecialchars($user['name']); ?></p>
                        <p><span class="font-semibold text-gray-700">Email:</span> <?php echo htmlspecialchars($user['email']); ?></p>
                        <p><span class="font-semibold text-gray-700">Role:</span> <?php echo htmlspecialchars($user['role']); ?></p>
                        <p><span class="font-semibold text-gray-700">Type:</span> <?php echo htmlspecialchars($user['user_type']); ?></p>
                        <p><span class="font-semibold text-gray-700">Status:</span> <?php echo htmlspecialchars($user['status']); ?></p>
                    </div>
                    <div>
                        <p><span class="font-semibold text-gray-700">Joined:</span> <?php echo htmlspecialchars($user['created_at']); ?></p>
                        <p><span class="font-semibold text-gray-700">Last Login:</span> <?php echo htmlspecialchars($user['last_login']); ?></p>
                    </div>
                </div>
            </div>

            <div class="bg-white shadow rounded-lg p-6">
                <h3 class="text-xl font-bold mb-4">My Reported Items</h3>
                <?php if (empty($items)): ?>
                    <p class="text-gray-600">You haven't reported any items yet.</p>
                <?php else: ?>
                    <div class="grid md:grid-cols-2 gap-4">
                        <?php foreach ($items as $item): ?>
                            <div class="border rounded p-4 bg-gray-50">
                                <h4 class="font-bold text-lg mb-2"><?php echo htmlspecialchars($item['item_name']); ?></h4>
                                <p><span class="font-semibold">Type:</span> <?php echo ucfirst($item['type']); ?></p>
                                <p><span class="font-semibold">Category:</span> <?php echo htmlspecialchars($item['category_name']); ?></p>
                                <p><span class="font-semibold">Location:</span> <?php echo htmlspecialchars($item['location']); ?></p>
                                <p><span class="font-semibold">Date:</span> <?php echo htmlspecialchars($item['date']); ?></p>
                                <a href="item-details.php?id=<?php echo $item['id']; ?>" class="text-blue-600 hover:underline mt-2 inline-block">View Details</a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <?php include('includes/footer.php'); ?>
</body>
</html>
