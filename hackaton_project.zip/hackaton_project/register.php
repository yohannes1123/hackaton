<?php
session_start();
require_once('includes/config.php');
require_once('includes/auth.php');

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: index.php');
    exit();
}

$error = '';
$success = false;

// Process registration form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $user_type = $_POST['user_type'] ?? '';
    
    // Validation
    if (empty($name) || empty($email) || empty($password) || empty($user_type)) {
        $error = 'All fields are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/@.*\.edu$/', $email)) {
        $error = 'Please use a valid university email address.';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters long.';
    } else {
        // Attempt registration
        $result = registerUser($name, $email, $password, $user_type);
        
        if ($result['success']) {
            $success = true;
        } else {
            $error = $result['message'];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('includes/head.php'); ?>
    <title>Register - Campus Finder</title>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen py-12">
    <div class="container mx-auto px-4 max-w-md">
        <div class="text-center mb-8">
            <h1 class="text-3xl font-bold text-blue-800">Campus Finder</h1>
            <p class="text-gray-600">University Lost & Found System</p>
        </div>
        
        <div class="bg-white rounded-lg shadow-md p-8">
            <h2 class="text-2xl font-bold mb-6 text-center">Create an Account</h2>
            
            <?php if ($error): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                    <p><?php echo htmlspecialchars($error); ?></p>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
                    <p>Registration successful! You can now <a href="login.php" class="font-bold underline">login</a>.</p>
                </div>
            <?php else: ?>
                <form method="POST" action="register.php">
                    <div class="mb-4">
                        <label for="name" class="block text-gray-700 text-sm font-bold mb-2">Full Name</label>
                        <input type="text" id="name" name="name" class="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500" required>
                    </div>
                    
                    <div class="mb-4">
                        <label for="email" class="block text-gray-700 text-sm font-bold mb-2">University Email</label>
                        <input type="email" id="email" name="email" class="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500" required>
                        <p class="text-sm text-gray-500 mt-1">Must be a valid university email address</p>
                    </div>
                    
                    <div class="mb-4">
                        <label for="user_type" class="block text-gray-700 text-sm font-bold mb-2">I am a</label>
                        <select id="user_type" name="user_type" class="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500" required>
                            <option value="">Select...</option>
                            <option value="student">Student</option>
                            <option value="staff">Staff Member</option>
                            <option value="faculty">Faculty</option>
                        </select>
                    </div>
                    
                    <div class="mb-4">
                        <label for="password" class="block text-gray-700 text-sm font-bold mb-2">Password</label>
                        <input type="password" id="password" name="password" class="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500" required>
                        <p class="text-sm text-gray-500 mt-1">At least 8 characters</p>
                    </div>
                    
                    <div class="mb-6">
                        <label for="confirm_password" class="block text-gray-700 text-sm font-bold mb-2">Confirm Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" class="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500" required>
                    </div>
                    
                    <div class="mb-6">
                        <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded focus:outline-none focus:shadow-outline transition duration-300">
                            Register
                        </button>
                    </div>
                    
                    <p class="text-center text-gray-600 text-sm">
                        Already have an account? <a href="login.php" class="text-blue-600 hover:text-blue-800">Login</a>
                    </p>
                </form>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="js/app.js"></script>
</body>
</html>