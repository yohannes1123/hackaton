<?php
session_start();
require_once('includes/config.php');
require_once('includes/auth.php');

// Redirect to login if not authenticated
if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

// Mark notification as read
if (isset($_GET['mark_read']) && is_numeric($_GET['mark_read'])) {
    markNotificationRead($_GET['mark_read'], $_SESSION['user_id']);
}

// Mark all notifications as read
if (isset($_GET['mark_all_read'])) {
    markAllNotificationsRead($_SESSION['user_id']);
}

// Get user's notifications
$notifications = getUserNotifications($_SESSION['user_id']);
$unread_count = countUnreadNotifications($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('includes/head.php'); ?>
    <title>Notifications - Campus Finder</title>
</head>
<body>
    <?php include('includes/header.php'); ?>
    
    <main class="container mx-auto px-4 py-8">
        <div class="max-w-3xl mx-auto">
            <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-2xl font-bold">Notifications</h2>
                    
                    <?php if ($unread_count > 0): ?>
                        <a href="notifications.php?mark_all_read=1" class="text-blue-600 hover:text-blue-800">
                            Mark all as read
                        </a>
                    <?php endif; ?>
                </div>
                
                <?php if (empty($notifications)): ?>
                    <div class="text-center py-8">
                        <div class="mb-4">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-16 w-16 mx-auto text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                            </svg>
                        </div>
                        <p class="text-lg text-gray-600">You don't have any notifications yet.</p>
                        <p class="mt-2 text-gray-500">Notifications will appear here when there's activity related to your items.</p>
                    </div>
                <?php else: ?>
                    <div class="divide-y">
                        <?php foreach ($notifications as $notification): ?>
                            <?php 
                                $bg_class = $notification['is_read'] ? 'bg-white' : 'bg-blue-50';
                                $icon_class = '';
                                $link = '#';
                                
                                switch ($notification['type']) {
                                    case 'match':
                                        $icon_class = 'text-blue-500';
                                        $link = 'item-details.php?id=' . $notification['related_id'];
                                        break;
                                    case 'claim':
                                        $icon_class = 'text-green-500';
                                        $link = 'item-details.php?id=' . $notification['item_id'];
                                        break;
                                    case 'resolved':
                                        $icon_class = 'text-purple-500';
                                        $link = 'item-details.php?id=' . $notification['item_id'];
                                        break;
                                    default:
                                        $icon_class = 'text-gray-500';
                                }
                            ?>
                            
                            <a href="<?php echo $link; ?>" class="block hover:bg-gray-50">
                                <div class="flex items-start p-4 <?php echo $bg_class; ?>">
                                    <div class="flex-shrink-0 pt-0.5">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 <?php echo $icon_class; ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <?php if ($notification['type'] === 'match'): ?>
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                            <?php elseif ($notification['type'] === 'claim'): ?>
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                            <?php elseif ($notification['type'] === 'resolved'): ?>
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                                            <?php else: ?>
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                                            <?php endif; ?>
                                        </svg>
                                    </div>
                                    
                                    <div class="ml-3 flex-1">
                                        <p class="text-sm font-medium text-gray-900">
                                            <?php echo htmlspecialchars($notification['message']); ?>
                                        </p>
                                        <p class="mt-1 text-sm text-gray-500">
                                            <?php echo formatDateTime($notification['created_at']); ?>
                                        </p>
                                    </div>
                                    
                                    <?php if (!$notification['is_read']): ?>
                                        <div class="ml-2 flex-shrink-0">
                                            <span class="inline-block h-2 w-2 rounded-full bg-blue-600"></span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
    
    <?php include('includes/footer.php'); ?>
    <script src="js/app.js"></script>
</body>
</html>