<?php
function connectDB() {
    $host = 'localhost';
    $db   = 'campus_finder';
    $user = 'root';
    $pass = '';
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        return new PDO($dsn, $user, $pass, $options);
    } catch (\PDOException $e) {
        throw new \PDOException($e->getMessage(), (int)$e->getCode());
    }
}

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

function getUserName() {
    if (!isLoggedIn()) {
        return '';
    }

    $conn = connectDB();
    $stmt = $conn->prepare("SELECT name FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $row = $stmt->fetch();

    return $row ? $row['name'] : 'User';
}

function getUserData($user_id) {
    $conn = connectDB();
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    return $stmt->fetch();
}

function loginUser($email, $password) {
    $conn = connectDB();
    $result = [
        'success' => false,
        'message' => '',
        'user_id' => 0,
        'user_role' => ''
    ];

    $stmt = $conn->prepare("SELECT id, password, role, status FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user) {
        $result['message'] = 'Invalid email or password.';
    } elseif ($user['status'] !== 'active') {
        $result['message'] = 'Your account is not active. Please contact the administrator.';
    } elseif ($password === $user['password']) {  // plain-text comparison
        $result['success'] = true;
        $result['user_id'] = $user['id'];
        $result['user_role'] = $user['role'];

        $update = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $update->execute([$user['id']]);
    } else {
        $result['message'] = 'Invalid email or password.';
    }

    return $result;
}

function registerUser($name, $email, $password, $user_type) {
    $conn = connectDB();
    $result = ['success' => false, 'message' => ''];

    $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $check->execute([$email]);

    if ($check->fetch()) {
        $result['message'] = 'Email address is already registered.';
    } else {
        $hashed_password = $password; // plain text password
        $role = 'user';

        $stmt = $conn->prepare("INSERT INTO users (name, email, password, user_type, role, status, created_at)
                                VALUES (?, ?, ?, ?, ?, 'active', NOW())");

        if ($stmt->execute([$name, $email, $hashed_password, $user_type, $role])) {
            $result['success'] = true;
        } else {
            $result['message'] = 'Error creating account.';
        }
    }

    return $result;
}
