<?php
// Additional functions for Campus Finder

/**
 * Get recent items
 * @param int $limit
 * @return array
 */
function getRecentItems($limit = 10) {
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT i.*, c.name AS category_name
        FROM items i
        LEFT JOIN item_categories c ON i.category_id = c.id
        WHERE i.status = 'open'
        ORDER BY i.created_at DESC
        LIMIT :limit
    ");
    $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
    $stmt->execute();

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Get items reported by a user
 * @param int $user_id
 * @param int $limit
 * @return array
 */
function getUserItems($user_id, $limit = 10) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT i.*, c.name AS category_name 
                           FROM items i
                           JOIN item_categories c ON i.category_id = c.id
                           WHERE i.user_id = :user_id
                           ORDER BY i.created_at DESC
                           LIMIT :limit");
    $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


/**
 * Get potential matches for a user's items
 * @param int $user_id
 * @param int $limit
 * @return array
 */
function getPotentialMatches($user_id, $limit = 10) {
    global $pdo;
    $matches = [];

    $stmt = $pdo->prepare("
        SELECT 
            m.match_score,
            i1.id AS your_item_id,
            i1.item_name AS your_item_name,
            i1.type AS your_item_type,
            i2.id AS matching_item_id,
            i2.item_name AS matching_item_name,
            i2.type AS matching_item_type,
            i2.user_id AS matching_item_user_id,
            u.name AS matching_item_user_name
        FROM item_matches m
        JOIN items i1 ON m.item_id = i1.id
        JOIN items i2 ON m.matching_item_id = i2.id
        JOIN users u ON i2.user_id = u.id
        WHERE i1.user_id = :user_id AND i1.status = 'open' AND i2.status = 'open'
        ORDER BY m.match_score DESC, m.created_at DESC
        LIMIT :limit
    ");

    $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
    $stmt->execute();

    $matches = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $matches;
}

/**
 * Get user's notifications
 * @param int $user_id
 * @return array
 */
function getUserNotifications($user_id) {
    $conn = connectDB();
    $notifications = [];
    
    $stmt = $conn->prepare("
        SELECT * FROM notifications
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT 50
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    
    $stmt->close();
    $conn->close();
    
    return $notifications;
}

/**
 * Count unread notifications
 * @param int $user_id
 * @return int
 */
function countUnreadNotifications($user_id) {
    $conn = connectDB();
    
    $stmt = $conn->prepare("
        SELECT COUNT(*) AS count
        FROM notifications
        WHERE user_id = ? AND is_read = 0
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    $count = $row['count'];
    
    $stmt->close();
    $conn->close();
    
    return $count;
}

/**
 * Mark notification as read
 * @param int $notification_id
 * @param int $user_id
 * @return boolean
 */
function markNotificationRead($notification_id, $user_id) {
    $conn = connectDB();
    
    $stmt = $conn->prepare("
        UPDATE notifications
        SET is_read = 1
        WHERE id = ? AND user_id = ?
    ");
    $stmt->bind_param("ii", $notification_id, $user_id);
    $success = $stmt->execute();
    
    $stmt->close();
    $conn->close();
    
    return $success;
}

/**
 * Mark all notifications as read
 * @param int $user_id
 * @return boolean
 */
function markAllNotificationsRead($user_id) {
    $conn = connectDB();
    
    $stmt = $conn->prepare("
        UPDATE notifications
        SET is_read = 1
        WHERE user_id = ?
    ");
    $stmt->bind_param("i", $user_id);
    $success = $stmt->execute();
    
    $stmt->close();
    $conn->close();
    
    return $success;
}

/**
 * Get user's conversations
 * @param int $user_id
 * @return array
 */
function getUserConversations($user_id) {
    $conn = connectDB(); // PDO connection
    $conversations = [];

    $sql = "
        SELECT 
            c.id,
            c.item_id,
            i.item_name,
            i.type AS item_type,
            CASE
                WHEN c.user1_id = :uid1 THEN c.user2_id
                ELSE c.user1_id
            END AS other_user_id,
            CASE
                WHEN c.user1_id = :uid2 THEN u2.name
                ELSE u1.name
            END AS other_user_name,
            (
                SELECT m.message
                FROM messages m
                WHERE m.conversation_id = c.id
                ORDER BY m.created_at DESC
                LIMIT 1
            ) AS last_message,
            (
                SELECT m.created_at
                FROM messages m
                WHERE m.conversation_id = c.id
                ORDER BY m.created_at DESC
                LIMIT 1
            ) AS last_message_time,
            (
                SELECT COUNT(*)
                FROM messages m
                WHERE m.conversation_id = c.id
                AND m.sender_id != :uid3
                AND m.is_read = 0
            ) AS unread_count
        FROM conversations c
        JOIN items i ON c.item_id = i.id
        JOIN users u1 ON c.user1_id = u1.id
        JOIN users u2 ON c.user2_id = u2.id
        WHERE c.user1_id = :uid4 OR c.user2_id = :uid5
        ORDER BY last_message_time DESC
    ";

    $stmt = $conn->prepare($sql);
    $stmt->execute([
        'uid1' => $user_id,
        'uid2' => $user_id,
        'uid3' => $user_id,
        'uid4' => $user_id,
        'uid5' => $user_id
    ]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


/**
 * Get conversation details
 * @param int $conversation_id
 * @param int $user_id
 * @return array|null
 */
function getConversationDetails($conversation_id, $user_id) {
    $conn = connectDB();
    
    $stmt = $conn->prepare("
        SELECT 
            c.*,
            i.id AS item_id,
            i.item_name AS item_name,
            i.type AS item_type,
            CASE
                WHEN c.user1_id = ? THEN c.user2_id
                ELSE c.user1_id
            END AS other_user_id,
            CASE
                WHEN c.user1_id = ? THEN u2.id
                ELSE u1.id
            END AS other_user_id,
            CASE
                WHEN c.user1_id = ? THEN u2.name
                ELSE u1.name
            END AS other_user_name,
            CASE
                WHEN c.user1_id = ? THEN u2.email
                ELSE u1.email
            END AS other_user_email
        FROM conversations c
        JOIN items i ON c.item_id = i.id
        JOIN users u1 ON c.user1_id = u1.id
        JOIN users u2 ON c.user2_id = u2.id
        WHERE c.id = ? AND (c.user1_id = ? OR c.user2_id = ?)
    ");
    $stmt->bind_param("iiiiiii", $user_id, $user_id, $user_id, $user_id, $conversation_id, $user_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return null;
    }
    
    $conversation = $result->fetch_assoc();
    
    // Get other user details
    $other_user = [
        'id' => $conversation['other_user_id'],
        'name' => $conversation['other_user_name'],
        'email' => $conversation['other_user_email']
    ];
    
    // Get item details
    $item = [
        'id' => $conversation['item_id'],
        'name' => $conversation['item_name'],
        'type' => $conversation['item_type']
    ];
    
    $stmt->close();
    $conn->close();
    
    return [
        'id' => $conversation['id'],
        'other_user' => $other_user,
        'item' => $item,
        'created_at' => $conversation['created_at']
    ];
}

/**
 * Get conversation messages
 * @param int $conversation_id
 * @return array
 */
function getConversationMessages($conversation_id) {
    $conn = connectDB();
    $messages = [];
    
    $stmt = $conn->prepare("
        SELECT m.*, u.name AS sender_name
        FROM messages m
        JOIN users u ON m.sender_id = u.id
        WHERE m.conversation_id = ?
        ORDER BY m.created_at ASC
    ");
    $stmt->bind_param("i", $conversation_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }
    
    $stmt->close();
    $conn->close();
    
    return $messages;
}

/**
 * Mark messages as read
 * @param int $conversation_id
 * @param int $user_id
 * @return boolean
 */
function markMessagesAsRead($conversation_id, $user_id) {
    $conn = connectDB();
    
    $stmt = $conn->prepare("
        UPDATE messages
        SET is_read = 1
        WHERE conversation_id = ? AND sender_id != ? AND is_read = 0
    ");
    $stmt->bind_param("ii", $conversation_id, $user_id);
    $success = $stmt->execute();
    
    $stmt->close();
    $conn->close();
    
    return $success;
}

/**
 * Send a message
 * @param int $conversation_id
 * @param int $sender_id
 * @param string $message
 * @return boolean
 */
function sendMessage($conversation_id, $sender_id, $message) {
    $conn = connectDB();
    
    // Insert message
    $stmt = $conn->prepare("
        INSERT INTO messages (conversation_id, sender_id, message, is_read, created_at)
        VALUES (?, ?, ?, 0, NOW())
    ");
    $stmt->bind_param("iis", $conversation_id, $sender_id, $message);
    $success = $stmt->execute();
    
    if ($success) {
        // Update conversation timestamp
        $update = $conn->prepare("
            UPDATE conversations
            SET updated_at = NOW()
            WHERE id = ?
        ");
        $update->bind_param("i", $conversation_id);
        $update->execute();
        $update->close();
    }
    
    $stmt->close();
    $conn->close();
    
    return $success;
}

/**
 * Get admin dashboard statistics
 * @return array
 */
function getAdminDashboardStats() {
    $conn = connectDB();
    $stats = [];

    // Total items
    $stmt = $conn->prepare("SELECT COUNT(*) AS count FROM items");
    $stmt->execute();
    $stats['total_items'] = $stmt->fetch()['count'];
    $stmt->closeCursor();

    // Lost items
    $stmt = $conn->prepare("SELECT COUNT(*) AS count FROM items WHERE type = 'lost'");
    $stmt->execute();
    $stats['lost_items'] = $stmt->fetch()['count'];
    $stmt->closeCursor();

    // Found items
    $stmt = $conn->prepare("SELECT COUNT(*) AS count FROM items WHERE type = 'found'");
    $stmt->execute();
    $stats['found_items'] = $stmt->fetch()['count'];
    $stmt->closeCursor();

    // Lost items change (weekly)
    $stmt = $conn->prepare("
        SELECT 
            (SELECT COUNT(*) FROM items WHERE type = 'lost' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)) AS current_week,
            (SELECT COUNT(*) FROM items WHERE type = 'lost' AND created_at BETWEEN DATE_SUB(CURDATE(), INTERVAL 14 DAY) AND DATE_SUB(CURDATE(), INTERVAL 7 DAY)) AS previous_week
    ");
    $stmt->execute();
    $result = $stmt->fetch();
    $current_week = $result['current_week'];
    $previous_week = $result['previous_week'];
    $stats['lost_items_change'] = $previous_week > 0 ? round((($current_week - $previous_week) / $previous_week) * 100) : 0;
    $stmt->closeCursor();

    // Found items change (weekly)
    $stmt = $conn->prepare("
        SELECT 
            (SELECT COUNT(*) FROM items WHERE type = 'found' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)) AS current_week,
            (SELECT COUNT(*) FROM items WHERE type = 'found' AND created_at BETWEEN DATE_SUB(CURDATE(), INTERVAL 14 DAY) AND DATE_SUB(CURDATE(), INTERVAL 7 DAY)) AS previous_week
    ");
    $stmt->execute();
    $result = $stmt->fetch();
    $current_week = $result['current_week'];
    $previous_week = $result['previous_week'];
    $stats['found_items_change'] = $previous_week > 0 ? round((($current_week - $previous_week) / $previous_week) * 100) : 0;
    $stmt->closeCursor();

    // Return rate
    $stmt = $conn->prepare("
        SELECT 
            (SELECT COUNT(*) FROM items WHERE status = 'closed') AS closed_items,
            (SELECT COUNT(*) FROM items) AS total_items
    ");
    $stmt->execute();
    $result = $stmt->fetch();
    $closed_items = $result['closed_items'];
    $total_items = $result['total_items'];
    $stats['return_rate'] = $total_items > 0 ? round(($closed_items / $total_items) * 100) : 0;
    $stmt->closeCursor();

    // Return rate change (monthly)
    $stmt = $conn->prepare("
        SELECT 
            (SELECT COUNT(*) FROM items WHERE status = 'closed' AND resolved_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)) /
            (SELECT COUNT(*) FROM items WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)) * 100 AS current_month_rate,
            (SELECT COUNT(*) FROM items WHERE status = 'closed' AND resolved_at BETWEEN DATE_SUB(CURDATE(), INTERVAL 60 DAY) AND DATE_SUB(CURDATE(), INTERVAL 30 DAY)) /
            (SELECT COUNT(*) FROM items WHERE created_at BETWEEN DATE_SUB(CURDATE(), INTERVAL 60 DAY) AND DATE_SUB(CURDATE(), INTERVAL 30 DAY)) * 100 AS previous_month_rate
    ");
    $stmt->execute();
    $result = $stmt->fetch();
    $current_month_rate = $result['current_month_rate'] ?? 0;
    $previous_month_rate = $result['previous_month_rate'] ?? 0;
    $stats['return_rate_change'] = $previous_month_rate > 0 ? round($current_month_rate - $previous_month_rate) : 0;
    $stmt->closeCursor();

    // Recent items
    $stmt = $conn->prepare("
        SELECT i.*, c.name AS category_name, u.name AS user_name
        FROM items i
        JOIN item_categories c ON i.category_id = c.id
        JOIN users u ON i.user_id = u.id
        ORDER BY i.created_at DESC
        LIMIT 10
    ");
    $stmt->execute();
    $stats['recent_items'] = $stmt->fetchAll();
    $stmt->closeCursor();

    // Items by day
    $stmt = $conn->prepare("
        SELECT 
            DATE(created_at) AS date,
            SUM(CASE WHEN type = 'lost' THEN 1 ELSE 0 END) AS lost,
            SUM(CASE WHEN type = 'found' THEN 1 ELSE 0 END) AS found
        FROM items
        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        GROUP BY DATE(created_at)
        ORDER BY date
    ");
    $stmt->execute();
    $stats['items_by_day'] = [];
    while ($row = $stmt->fetch()) {
        $stats['items_by_day'][] = [
            'date' => date('M d', strtotime($row['date'])),
            'lost' => (int)$row['lost'],
            'found' => (int)$row['found']
        ];
    }
    $stmt->closeCursor();

    // Items by category
    $stmt = $conn->prepare("
        SELECT c.name, COUNT(i.id) AS count
        FROM items i
        JOIN item_categories c ON i.category_id = c.id
        GROUP BY c.id
        ORDER BY count DESC
    ");
    $stmt->execute();
    $stats['items_by_category'] = [];
    while ($row = $stmt->fetch()) {
        $stats['items_by_category'][] = [
            'name' => $row['name'],
            'count' => (int)$row['count']
        ];
    }
    $stmt->closeCursor();

    return $stats;
}


/**
 * Approve items (admin function)
 * @param array $item_ids
 * @return boolean
 */
function approveItems($item_ids) {
    $conn = connectDB();
    $success = true;
    
    foreach ($item_ids as $item_id) {
        $stmt = $conn->prepare("
            UPDATE items
            SET status = 'open'
            WHERE id = ? AND status = 'pending'
        ");
        $stmt->bind_param("i", $item_id);
        
        if (!$stmt->execute()) {
            $success = false;
        } else {
            // Get item owner
            $user_query = $conn->prepare("SELECT user_id FROM items WHERE id = ?");
            $user_query->bind_param("i", $item_id);
            $user_query->execute();
            $user_result = $user_query->get_result();
            
            if ($user_row = $user_result->fetch_assoc()) {
                // Create notification
                createNotification($user_row['user_id'], 'approval', $item_id, null, 'Your item report has been approved.');
            }
            
            $user_query->close();
        }
        
        $stmt->close();
    }
    
    $conn->close();
    
    return $success;
}

/**
 * Reject items (admin function)
 * @param array $item_ids
 * @return boolean
 */
function rejectItems($item_ids) {
    $conn = connectDB();
    $success = true;
    
    foreach ($item_ids as $item_id) {
        $stmt = $conn->prepare("
            UPDATE items
            SET status = 'rejected'
            WHERE id = ?
        ");
        $stmt->bind_param("i", $item_id);
        
        if (!$stmt->execute()) {
            $success = false;
        } else {
            // Get item owner
            $user_query = $conn->prepare("SELECT user_id FROM items WHERE id = ?");
            $user_query->bind_param("i", $item_id);
            $user_query->execute();
            $user_result = $user_query->get_result();
            
            if ($user_row = $user_result->fetch_assoc()) {
                // Create notification
                createNotification($user_row['user_id'], 'rejection', $item_id, null, 'Your item report has been rejected.');
            }
            
            $user_query->close();
        }
        
        $stmt->close();
    }
    
    $conn->close();
    
    return $success;
}

/**
 * Delete items (admin function)
 * @param array $item_ids
 * @return boolean
 */
function deleteItems($item_ids) {
    $conn = connectDB();
    $success = true;
    
    foreach ($item_ids as $item_id) {
        // First, check if there's a photo to delete
        $photo_query = $conn->prepare("SELECT photo, user_id FROM items WHERE id = ?");
        $photo_query->bind_param("i", $item_id);
        $photo_query->execute();
        $photo_result = $photo_query->get_result();
        $photo_row = $photo_result->fetch_assoc();
        
        // Store user_id for notification
        $user_id = $photo_row['user_id'];
        
        // Delete photo file if exists
        if ($photo_row && !empty($photo_row['photo'])) {
            $photo_path = UPLOAD_DIR . $photo_row['photo'];
            if (file_exists($photo_path)) {
                unlink($photo_path);
            }
        }
        
        // Delete related records (foreign key constraints)
        $tables = ['item_claims', 'item_matches', 'notifications'];
        
        foreach ($tables as $table) {
            $delete = $conn->prepare("DELETE FROM $table WHERE item_id = ?");
            $delete->bind_param("i", $item_id);
            $delete->execute();
            $delete->close();
        }
        
        // Delete the item
        $stmt = $conn->prepare("DELETE FROM items WHERE id = ?");
        $stmt->bind_param("i", $item_id);
        
        if (!$stmt->execute()) {
            $success = false;
        } else if ($user_id) {
            // Create notification about deletion
            createNotification($user_id, 'deletion', null, null, 'Your item report has been deleted by an administrator.');
        }
        
        $stmt->close();
        $photo_query->close();
    }
    
    $conn->close();
    
    return $success;
}

function getItemCategories() {
    global $pdo; // Use the global PDO connection
    $categories = [];

    try {
        $stmt = $pdo->prepare("SELECT id, name FROM item_categories ORDER BY name ASC");
        $stmt->execute();
        $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        die("Error fetching categories: " . $e->getMessage());
    }

    return $categories;
}



function saveReportLost($user_id, $item_name, $category_id, $date_lost, $location, $description, $contact_method) {
    $conn = connectDB(); // Must return a PDO instance

    try {
        $stmt = $conn->prepare("
            INSERT INTO items (user_id, item_name, category_id, date, location, description, contact_method, type, status, created_at)
            VALUES (:user_id, :item_name, :category_id, :date_lost, :location, :description, :contact_method, 'lost', 'open', NOW())
        ");

        $stmt->execute([
            ':user_id' => $user_id,
            ':item_name' => $item_name,
            ':category_id' => $category_id,
            ':date_lost' => $date_lost,
            ':location' => $location,
            ':description' => $description,
            ':contact_method' => $contact_method
        ]);

        return [
            'success' => true,
            'report_id' => $conn->lastInsertId()
        ];

    } catch (PDOException $e) {
        return [
            'success' => false,
            'message' => "Database error: " . $e->getMessage()
        ];
    }
}



    function saveReportFound($user_id, $item_name, $category_id, $date_found, $location, $description, $photo, $turned_in, $turned_in_location) {
    global $pdo;

    try {
        $stmt = $pdo->prepare("
            INSERT INTO items (
                user_id, item_name, category_id, date, location, description,
                photo, type, turned_in, turned_in_location, status, created_at
            ) VALUES (
                :user_id, :item_name, :category_id, :date, :location, :description,
                :photo, 'found', :turned_in, :turned_in_location, 'open', NOW()
            )
        ");

        $stmt->execute([
            ':user_id' => $user_id,
            ':item_name' => $item_name,
            ':category_id' => $category_id,
            ':date' => $date_found,
            ':location' => $location,
            ':description' => $description,
            ':photo' => $photo,
            ':turned_in' => $turned_in,
            ':turned_in_location' => $turned_in_location
        ]);

        return [
            'success' => true,
            'report_id' => $pdo->lastInsertId()
        ];
    } catch (PDOException $e) {
        return [
            'success' => false,
            'message' => 'Error saving report: ' . $e->getMessage()
        ];
    }
}



function uploadItemPhoto($file) {
    $target_dir = "uploads/";
    $filename = basename($file["name"]);
    $target_file = $target_dir . uniqid() . "_" . $filename;
    $uploadOk = true;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check file size (max 5MB)
    if ($file["size"] > 5 * 1024 * 1024) {
        return ['success' => false, 'message' => 'File is too large. Max 5MB allowed.'];
    }

    // Allow only specific file types
    $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
    if (!in_array($imageFileType, $allowed_types)) {
        return ['success' => false, 'message' => 'Only JPG, JPEG, PNG & GIF files are allowed.'];
    }

    // Attempt to move uploaded file
    if (move_uploaded_file($file["tmp_name"], $target_file)) {
        return ['success' => true, 'filename' => $target_file];
    } else {
        return ['success' => false, 'message' => 'Error uploading your file.'];
    }
function login($email, $password) {
    global $pdo;

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->execute([':email' => $email]);
    $user = $stmt->fetch();

    // TEMPORARY: Direct password match (no hash)
    if ($user && $password === $user['password']) {
        $_SESSION['user_id'] = $user['id'];
        return true;
    }

    return false;
}


}
