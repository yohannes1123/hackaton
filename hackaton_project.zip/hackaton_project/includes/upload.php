

<?php

function findPotentialMatches($item_id, $type) {
    global $pdo;

    // Determine the opposite type
    $match_type = $type === 'lost' ? 'found' : 'lost';

    // Get the item details
    $stmt = $pdo->prepare("SELECT item_name, description FROM items WHERE id = ?");
    $stmt->execute([$item_id]);
    $item = $stmt->fetch();

    if (!$item) {
        return [];
    }

    $keywords = explode(' ', $item['item_name'] . ' ' . $item['description']);
    $keywords = array_filter($keywords); // Remove empty words

    // Build dynamic LIKE query
    $like_clauses = [];
    $params = [];
    foreach ($keywords as $word) {
        $like_clauses[] = "(item_name LIKE ? OR description LIKE ?)";
        $params[] = '%' . $word . '%';
        $params[] = '%' . $word . '%';
    }

    if (empty($like_clauses)) {
        return [];
    }

    $sql = "SELECT * FROM items 
            WHERE type = ? AND status = 'open' AND id != ? 
              AND (" . implode(' OR ', $like_clauses) . ") 
            ORDER BY created_at DESC 
            LIMIT 10";

    array_unshift($params, $match_type, $item_id); // prepend type and ID

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}




function getFilteredItems($type, $category, $search, $date_from, $date_to, $location, $status, $limit = 10, $offset = 0) {
    global $pdo;

    $where = ["type = :type"];
    $params = [':type' => $type];

    if (!empty($category)) {
        $where[] = "category_id = :category";
        $params[':category'] = $category;
    }

    if (!empty($search)) {
        $where[] = "(item_name LIKE :search OR description LIKE :search)";
        $params[':search'] = '%' . $search . '%';
    }

    if (!empty($date_from)) {
        $where[] = "date >= :date_from";
        $params[':date_from'] = $date_from;
    }

    if (!empty($date_to)) {
        $where[] = "date <= :date_to";
        $params[':date_to'] = $date_to;
    }

    if (!empty($location)) {
        $where[] = "location = :location";
        $params[':location'] = $location;
    }

    if (!empty($status)) {
        $where[] = "status = :status";
        $params[':status'] = $status;
    }

    $where_clause = implode(" AND ", $where);

    // Count total items
    $count_sql = "SELECT COUNT(*) FROM items WHERE $where_clause";
    $count_stmt = $pdo->prepare($count_sql);
    $count_stmt->execute($params);
    $total = $count_stmt->fetchColumn();

    // Get paginated items
    $sql = "SELECT i.*, c.name AS category_name FROM items i 
            JOIN item_categories c ON i.category_id = c.id 
            WHERE $where_clause 
            ORDER BY created_at DESC 
            LIMIT :limit OFFSET :offset";

    $stmt = $pdo->prepare($sql);

    // Add LIMIT/OFFSET separately
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }

    $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);

    $stmt->execute();
    $items = $stmt->fetchAll();

    return [
        'items' => $items,
        'total' => $total
    ];
}

function formatDate($date) {
    $timestamp = strtotime($date);
    return date('F j, Y', $timestamp); // Example: January 20, 2024
}
function formatLocation($location) {
    return htmlspecialchars($location);
}

function getItemDetails($item_id) {
    $conn = connectDB(); // Assumes connectDB() returns a PDO connection

    $stmt = $conn->prepare("
        SELECT i.*, 
               c.name AS category_name, 
               u.name AS user_name,
               u.id AS user_id
        FROM items i
        JOIN item_categories c ON i.category_id = c.id
        JOIN users u ON i.user_id = u.id
        WHERE i.id = :item_id
        LIMIT 1
    ");

    $stmt->execute([':item_id' => $item_id]);
    $item = $stmt->fetch(PDO::FETCH_ASSOC);

    $conn = null;

    return $item ?: null;
}

function getItemClaims($item_id) {
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT ic.*, u.name AS user_name
        FROM item_claims ic
        JOIN users u ON ic.user_id = u.id
        WHERE ic.item_id = :item_id
        ORDER BY ic.created_at DESC
    ");
    $stmt->execute([':item_id' => $item_id]);
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function formatTurnedInLocation($location_code) {
    $locations = [
        'campus_security'    => 'Campus Security Office',
        'student_services'   => 'Student Services Center',
        'residence_hall'     => 'Residence Hall Front Desk',
        'library_desk'       => 'Library Information Desk',
        'department_office'  => 'Department Office',
        'other'              => 'Other',
    ];

    return $locations[$location_code] ?? 'Unknown Location';
}

function formatDateTime($datetime) {
    return date('F j, Y \a\t g:i A', strtotime($datetime)); // e.g., April 12, 2025 at 2:15 PM
}




?>