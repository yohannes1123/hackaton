<header class="bg-white shadow">
    <div class="container mx-auto px-4">
        <div class="flex justify-between items-center py-4">
            <div class="flex items-center">
                <a href="index.php" class="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-blue-600" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd" />
                    </svg>
                    <span class="ml-2 text-xl font-bold text-gray-900">LostLink</span>
                </a>
            </div>
            
            <div class="hidden md:flex items-center space-x-6">
                <a href="index.php" class="text-gray-700 hover:text-blue-600 font-medium">Home</a>
                <a href="report-lost.php" class="text-gray-700 hover:text-blue-600 font-medium">Report Lost</a>
                <a href="report-found.php" class="text-gray-700 hover:text-blue-600 font-medium">Report Found</a>
                <a href="browse.php" class="text-gray-700 hover:text-blue-600 font-medium">Browse Items</a>
                <?php if (isAdmin()): ?>
                    <a href="admin/dashboard.php" class="text-gray-700 hover:text-blue-600 font-medium">Admin</a>
                <?php endif; ?>
            </div>
            
            <div class="flex items-center">
                <div class="relative">
                    <button id="userMenuBtn" class="flex items-center focus:outline-none">
                        <span class="mr-1 text-gray-700"><?php echo htmlspecialchars(getUserName()); ?></span>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-700" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                        </svg>
                    </button>
                    
                 <div id="userDropdown" class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg hidden z-10">
    <?php if (isset($_SESSION['user_id'])): ?>
        <a href="pro.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Profile</a>
        <a href="myprofile.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">My Reports</a>
        <a href="messages.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Messages</a>
        <a href="logout.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Logout</a>
    <?php else: ?>
        <a href="login.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Login</a>
    <?php endif; ?>
</div>


                <button class="md:hidden ml-4 focus:outline-none" id="menuToggle">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-gray-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                </button>
            </div>
        </div>

        <!-- Mobile menu -->
        <div class="md:hidden hidden" id="mobileMenu">
            <div class="py-2 space-y-1 border-t">
                <a href="index.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">Home</a>
                <a href="report-lost.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">Report Lost</a>
                <a href="report-found.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">Report Found</a>
                <a href="browse.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">Browse Items</a>
                <?php if (isAdmin()): ?>
                    <a href="admin/dashboard.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">Admin</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</header>

<!-- Scripts -->
<script>
    // Mobile menu toggle
    document.getElementById('menuToggle').addEventListener('click', function() {
        const mobileMenu = document.getElementById('mobileMenu');
        mobileMenu.classList.toggle('hidden');
    });

    // User menu toggle
    document.getElementById('userMenuBtn').addEventListener('click', function (e) {
        e.stopPropagation();
        document.getElementById('userDropdown').classList.toggle('hidden');
    });

    // Hide dropdown if clicked outside
    document.addEventListener('click', function (event) {
        const dropdown = document.getElementById('userDropdown');
        const button = document.getElementById('userMenuBtn');
        if (!button.contains(event.target)) {
            dropdown.classList.add('hidden');
        }
    });
</script>
