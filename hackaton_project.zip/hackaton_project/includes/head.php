<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="icon" type="image/png" href="img/favicon.png">
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    body {
        font-family: 'Inter', sans-serif;
        background-color: #f5f7fa;
    }
    
    .transition {
        transition: all 0.3s ease;
    }
    
    /* Animation for new items */
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .animate-fade-in {
        animation: fadeIn 0.5s ease-out forwards;
    }
    
    /* Responsive table */
    @media (max-width: 640px) {
        .responsive-table thead {
            display: none;
        }
        
        .responsive-table tbody tr {
            display: block;
            margin-bottom: 1rem;
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            overflow: hidden;
        }
        
        .responsive-table tbody td {
            display: flex;
            justify-content: space-between;
            padding: 0.75rem 1rem;
            text-align: right;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .responsive-table tbody td:last-child {
            border-bottom: none;
        }
        
        .responsive-table tbody td::before {
            content: attr(data-label);
            font-weight: 600;
            text-align: left;
        }
    }
    
    /* Line clamp */
    .line-clamp-2 {
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }
</style>