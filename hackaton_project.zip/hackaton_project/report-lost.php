<?php
session_start();
require_once('includes/config.php');
require_once('includes/auth.php');

require_once('includes/auth.php');
require_once('includes/config.php');
require_once('includes/functions.php');

require_once('includes/upload.php');

// Redirect to login if not authenticated
if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$error = '';
$success = false;

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_name = $_POST['item_name'] ?? '';
    $category = $_POST['category'] ?? '';
    $date_lost = $_POST['date_lost'] ?? '';
    $location = $_POST['location'] ?? '';
    $description = $_POST['description'] ?? '';
    $contact_method = $_POST['contact_method'] ?? '';
    
    // Validation
    if (empty($item_name) || empty($category) || empty($date_lost) || empty($location)) {
        $error = 'Please fill in all required fields.';
    } else {
        // Save report to database
        $result = saveReportLost($_SESSION['user_id'], $item_name, $category, $date_lost, $location, $description, $contact_method);
        
        if ($result['success']) {
            $success = true;
            $report_id = $result['report_id'];
            
            // Check for potential matches
            findPotentialMatches($report_id, 'lost');
        } else {
            $error = $result['message'];
        }
    }
}

// Get categories
$categories = getItemCategories();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('includes/head.php'); ?>
    <title>Report Lost Item - Campus Finder</title>
</head>
<body>
    <?php include('includes/header.php'); ?>
    
    <main class="container mx-auto px-4 py-8">
        <div class="max-w-2xl mx-auto">
            <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                <h2 class="text-2xl font-bold mb-6">Report a Lost Item</h2>
                
                <?php if ($error): ?>
                    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                        <p><?php echo htmlspecialchars($error); ?></p>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
                        <p>Your lost item report has been submitted successfully.</p>
                        <p class="mt-2">We'll notify you if someone reports finding a similar item.</p>
                        <div class="mt-4">
                            <a href="index.php" class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition duration-300">Return to Dashboard</a>
                            <a href="report-lost.php" class="inline-block bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded-md transition duration-300 ml-2">Report Another Item</a>
                        </div>
                    </div>
                <?php else: ?>
                    <form method="POST" action="report-lost.php" enctype="multipart/form-data">
                        <div class="mb-4">
                            <label for="item_name" class="block text-gray-700 text-sm font-bold mb-2">Item Name *</label>
                            <input type="text" id="item_name" name="item_name" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500" required>
                        </div>
                        
                        <div class="mb-4">
                            <label for="category" class="block text-gray-700 text-sm font-bold mb-2">Category *</label>
                            <select id="category" name="category" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500" required>
                                <option value="">Select a category</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo htmlspecialchars($cat['id']); ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-4">
                            <label for="date_lost" class="block text-gray-700 text-sm font-bold mb-2">Date Lost *</label>
                            <input type="date" id="date_lost" name="date_lost" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500" required>
                        </div>
                        
                        <div class="mb-4">
                            <label for="location" class="block text-gray-700 text-sm font-bold mb-2">Location Last Seen *</label>
                            <select id="location" name="location" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500" required>
                                <option value="">Select location</option>
                                <option value="library">Library</option>
                                <option value="student_center">Student Center</option>
                                <option value="dining_hall">Dining Hall</option>
                                <option value="gym">Gymnasium</option>
                                <option value="dorm">Dormitory</option>
                                <option value="classroom">Classroom</option>
                                <option value="outdoor">Outdoor Areas</option>
                                <option value="parking">Parking Lot</option>
                                <option value="other">Other (specify in description)</option>
                            </select>
                        </div>
                        
                        <div class="mb-4">
                            <label for="description" class="block text-gray-700 text-sm font-bold mb-2">Description</label>
                            <textarea id="description" name="description" rows="4" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500" placeholder="Please provide a detailed description of the item (color, brand, identifying features, etc.)"></textarea>
                        </div>
                        
                        <div class="mb-6">
                            <label for="contact_method" class="block text-gray-700 text-sm font-bold mb-2">Preferred Contact Method</label>
                            <select id="contact_method" name="contact_method" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500">
                                <option value="email">Email</option>
                                <option value="phone">Phone</option>
                                <option value="both">Both Email and Phone</option>
                            </select>
                        </div>
                        
                        <div class="flex items-center justify-end">
                            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-6 rounded-md focus:outline-none focus:shadow-outline transition duration-300">
                                Submit Report
                            </button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </main>
    
    <?php include('includes/footer.php'); ?>
    <script src="js/app.js"></script>
</body>
</html>