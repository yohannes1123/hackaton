<?php
require_once('includes/config.php');
require_once('includes/functions.php');
require_once('includes/auth.php');
require_once('includes/upload.php');
// Get recent items
$recent_items = getRecentItems(6);
?>

<div class="space-y-6">
    <?php if (empty($recent_items)): ?>
        <p class="text-gray-600 text-center py-4">No recent activity yet.</p>
    <?php else: ?>
        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($recent_items as $item): ?>
                <div class="bg-white border rounded-lg overflow-hidden hover:shadow-lg transition duration-300 animate-fade-in">
                    <div class="p-4 border-b">
                        <div class="flex justify-between items-start">
                            <div>
                                <h3 class="font-bold text-lg"><?php echo htmlspecialchars($item['item_name']); ?></h3>
                                <p class="text-sm text-gray-600">
                                    <?php echo $item['type'] === 'lost' ? 'Lost on ' : 'Found on '; ?>
                                    <?php echo htmlspecialchars(formatDate($item['date'])); ?>
                                </p>
                            </div>
                            <span class="rounded-full px-3 py-1 text-xs font-semibold 
                                <?php echo $item['type'] === 'lost' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'; ?>">
                                <?php echo $item['type'] === 'lost' ? 'Lost' : 'Found'; ?>
                            </span>
                        </div>
                    </div>
                    
                    <?php if (!empty($item['photo'])): ?>
                        <img src="uploads/<?php echo htmlspecialchars($item['photo']); ?>" alt="<?php echo htmlspecialchars($item['item_name']); ?>" class="w-full h-36 object-cover">
                    <?php else: ?>
                        <div class="w-full h-36 bg-gray-100 flex items-center justify-center">
                            <span class="text-gray-400">No image available</span>
                        </div>
                    <?php endif; ?>
                    
                    <div class="p-4">
                        <p class="text-sm mb-2">
                            <span class="font-semibold">Category:</span> <?php echo htmlspecialchars($item['category_name']); ?>
                        </p>
                        <p class="text-sm mb-4">
                            <span class="font-semibold">Location:</span> <?php echo htmlspecialchars(formatLocation($item['location'])); ?>
                        </p>
                        
                        <a href="item-details.php?id=<?php echo htmlspecialchars($item['id']); ?>" class="block text-center bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition duration-300">
                            View Details
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>