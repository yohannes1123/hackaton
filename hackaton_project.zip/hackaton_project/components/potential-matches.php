<?php
// Get potential matches for user's items
$potential_matches = getPotentialMatches($_SESSION['user_id'], 5);
?>

<div>
    <?php if (empty($potential_matches)): ?>
        <p class="text-gray-600 text-center py-4">No potential matches found for your items.</p>
    <?php else: ?>
        <div class="space-y-4">
            <?php foreach ($potential_matches as $match): ?>
                <div class="bg-blue-50 rounded-lg p-4 border border-blue-200 hover:shadow-md transition duration-300">
                    <div class="flex justify-between items-start">
                        <div>
                            <h3 class="font-semibold text-blue-800">
                                <?php if ($match['your_item_type'] === 'lost'): ?>
                                    Someone found a similar item
                                <?php else: ?>
                                    Someone lost a similar item
                                <?php endif; ?>
                            </h3>
                            <p class="text-sm text-gray-700 mt-1">
                                Match score: 
                                <span class="font-medium">
                                    <?php echo $match['match_score']; ?>%
                                </span>
                            </p>
                        </div>
                        <span class="rounded-full px-3 py-1 text-xs font-semibold 
                            <?php echo $match['matching_item_type'] === 'lost' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'; ?>">
                            <?php echo $match['matching_item_type'] === 'lost' ? 'Lost Item' : 'Found Item'; ?>
                        </span>
                    </div>
                    
                    <div class="mt-2">
                        <p class="text-sm mb-1">
                            <span class="font-semibold">Your item:</span> <?php echo htmlspecialchars($match['your_item_name']); ?>
                        </p>
                        <p class="text-sm mb-3">
                            <span class="font-semibold">Matching item:</span> <?php echo htmlspecialchars($match['matching_item_name']); ?>
                        </p>
                    </div>
                    
                    <div class="flex justify-end">
                        <a href="item-details.php?id=<?php echo htmlspecialchars($match['matching_item_id']); ?>" class="text-blue-600 hover:text-blue-800 text-sm font-medium">
                            View Details
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="mt-4 text-right">
            <a href="matches.php" class="text-blue-600 hover:text-blue-800">View All Matches</a>
        </div>
    <?php endif; ?>
</div>