<?php
// Get user's recent reports
$user_reports = getUserItems($_SESSION['user_id'], 5);
?>

<div>
    <?php if (empty($user_reports)): ?>
        <div class="text-center py-4">
            <p class="text-gray-600 mb-3">You haven't reported any items yet.</p>
            <div class="flex flex-wrap justify-center gap-2">
                <a href="report-lost.php" class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition duration-300">Report Lost Item</a>
                <a href="report-found.php" class="inline-block bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-md transition duration-300">Report Found Item</a>
            </div>
        </div>
    <?php else: ?>
        <div class="overflow-hidden">
            <table class="min-w-full responsive-table">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php foreach ($user_reports as $report): ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap" data-label="Item">
                                <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($report['item_name']); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap" data-label="Type">
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $report['type'] === 'lost' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'; ?>">
                                    <?php echo $report['type'] === 'lost' ? 'Lost' : 'Found'; ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500" data-label="Date">
                                <?php echo htmlspecialchars(formatDate($report['date'])); ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap" data-label="Status">
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $report['status'] === 'open' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'; ?>">
                                    <?php echo ucfirst($report['status']); ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium" data-label="Action">
                                <a href="item-details.php?id=<?php echo htmlspecialchars($report['id']); ?>" class="text-blue-600 hover:text-blue-900">View</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <div class="mt-4 text-right">
            <a href="my-items.php" class="text-blue-600 hover:text-blue-800">View All Reports</a>
        </div>
    <?php endif; ?>
</div>