<?php
session_start();
require_once('../includes/config.php');
require_once('../includes/auth.php');
require_once('../includes/functions.php');
require_once('../includes/upload.php');

// Redirect if not admin
if (!isAdmin()) {
    header('Location: ../index.php');
    exit();
}

// Get filter parameters
$item_type = $_GET['type'] ?? 'all'; // all, lost, found
$category = $_GET['category'] ?? '';
$search = $_GET['search'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$location = $_GET['location'] ?? '';
$status = $_GET['status'] ?? 'all'; // open, closed, all

// Get categories for filter
$categories = getItemCategories();

// Process bulk actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_action']) && isset($_POST['selected_items'])) {
    $bulk_action = $_POST['bulk_action'];
    $selected_items = $_POST['selected_items'];
    
    if (!empty($selected_items)) {
        switch ($bulk_action) {
            case 'approve':
                approveItems($selected_items);
                break;
            case 'reject':
                rejectItems($selected_items);
                break;
            case 'delete':
                deleteItems($selected_items);
                break;
        }
    }
    
    // Redirect to avoid form resubmission
    header('Location: items.php?type=' . urlencode($item_type) . '&category=' . urlencode($category) . '&search=' . urlencode($search) . '&date_from=' . urlencode($date_from) . '&date_to=' . urlencode($date_to) . '&location=' . urlencode($location) . '&status=' . urlencode($status));
    exit();
}

// Get paginated results
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 20;
$offset = ($page - 1) * $per_page;

// Get items
$result = getFilteredItems($item_type, $category, $search, $date_from, $date_to, $location, $status, $per_page, $offset);
$items = $result['items'];
$total_items = $result['total'];
$total_pages = ceil($total_items / $per_page);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('../includes/head.php'); ?>
    <title>Manage Items - Admin Dashboard</title>
</head>
<body>
    <?php include('includes/admin-header.php'); ?>
    
    <main class="container mx-auto px-4 py-8">
        <div class="mb-6">
            <h2 class="text-2xl font-bold mb-4">Manage Items</h2>
            
            <div class="bg-white rounded-lg shadow-md p-6">
                <form method="GET" action="items.php" class="mb-6">
                    <div class="grid md:grid-cols-3 gap-4">
                        <div>
                            <label for="type" class="block text-gray-700 text-sm font-bold mb-2">Item Type</label>
                            <select id="type" name="type" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500">
                                <option value="all" <?php echo $item_type === 'all' ? 'selected' : ''; ?>>All Items</option>
                                <option value="lost" <?php echo $item_type === 'lost' ? 'selected' : ''; ?>>Lost Items</option>
                                <option value="found" <?php echo $item_type === 'found' ? 'selected' : ''; ?>>Found Items</option>
                            </select>
                        </div>
                        
                        <div>
                            <label for="category" class="block text-gray-700 text-sm font-bold mb-2">Category</label>
                            <select id="category" name="category" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500">
                                <option value="">All Categories</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo htmlspecialchars($cat['id']); ?>" <?php echo $category == $cat['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($cat['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div>
                            <label for="location" class="block text-gray-700 text-sm font-bold mb-2">Location</label>
                            <select id="location" name="location" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500">
                                <option value="">All Locations</option>
                                <option value="library" <?php echo $location === 'library' ? 'selected' : ''; ?>>Library</option>
                                <option value="student_center" <?php echo $location === 'student_center' ? 'selected' : ''; ?>>Student Center</option>
                                <option value="dining_hall" <?php echo $location === 'dining_hall' ? 'selected' : ''; ?>>Dining Hall</option>
                                <option value="gym" <?php echo $location === 'gym' ? 'selected' : ''; ?>>Gymnasium</option>
                                <option value="dorm" <?php echo $location === 'dorm' ? 'selected' : ''; ?>>Dormitory</option>
                                <option value="classroom" <?php echo $location === 'classroom' ? 'selected' : ''; ?>>Classroom</option>
                                <option value="outdoor" <?php echo $location === 'outdoor' ? 'selected' : ''; ?>>Outdoor Areas</option>
                                <option value="parking" <?php echo $location === 'parking' ? 'selected' : ''; ?>>Parking Lot</option>
                                <option value="other" <?php echo $location === 'other' ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="grid md:grid-cols-3 gap-4 mt-4">
                        <div>
                            <label for="search" class="block text-gray-700 text-sm font-bold mb-2">Search</label>
                            <input type="text" id="search" name="search" value="<?php echo htmlspecialchars($search); ?>" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500" placeholder="Search by keywords...">
                        </div>
                        
                        <div>
                            <label for="date_from" class="block text-gray-700 text-sm font-bold mb-2">Date From</label>
                            <input type="date" id="date_from" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500">
                        </div>
                        
                        <div>
                            <label for="date_to" class="block text-gray-700 text-sm font-bold mb-2">Date To</label>
                            <input type="date" id="date_to" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500">
                        </div>
                    </div>
                    
                    <div class="flex justify-between items-center mt-4">
                        <div>
                            <label for="status" class="block text-gray-700 text-sm font-bold mb-2">Status</label>
                            <select id="status" name="status" class="shadow appearance-none border rounded w-40 py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500">
                                <option value="all" <?php echo $status === 'all' ? 'selected' : ''; ?>>All</option>
                                <option value="open" <?php echo $status === 'open' ? 'selected' : ''; ?>>Open</option>
                                <option value="closed" <?php echo $status === 'closed' ? 'selected' : ''; ?>>Closed</option>
                                <option value="pending" <?php echo $status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="rejected" <?php echo $status === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                            </select>
                        </div>
                        
                        <div class="mt-6">
                            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md focus:outline-none focus:shadow-outline transition duration-300">
                                Filter Results
                            </button>
                            <a href="items.php" class="ml-2 text-blue-600 hover:text-blue-800">Reset</a>
                        </div>
                    </div>
                </form>
                
                <?php if (empty($items)): ?>
                    <div class="text-center py-8">
                        <p class="text-lg text-gray-600">No items found matching your criteria.</p>
                        <p class="mt-2">Try adjusting your filters or check back later.</p>
                    </div>
                <?php else: ?>
                    <form method="POST" action="items.php">
                        <div class="flex justify-between items-center mb-4">
                            <div>
                                <select name="bulk_action" class="shadow border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500">
                                    <option value="">-- Bulk Actions --</option>
                                    <option value="approve">Approve</option>
                                    <option value="reject">Reject</option>
                                    <option value="delete">Delete</option>
                                </select>
                                <button type="submit" class="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-4 rounded-md focus:outline-none focus:shadow-outline transition duration-300 ml-2">
                                    Apply
                                </button>
                            </div>
                            
                            <p class="text-gray-600">
                                Showing <?php echo ($offset + 1); ?>-<?php echo min($offset + count($items), $total_items); ?> of <?php echo $total_items; ?> items
                            </p>
                        </div>
                        
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <input type="checkbox" id="selectAll" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                        </th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                        <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php foreach ($items as $item): ?>
                                        <tr class="hover:bg-gray-50">
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <input type="checkbox" name="selected_items[]" value="<?php echo $item['id']; ?>" class="item-checkbox h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($item['item_name']); ?></div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $item['type'] === 'lost' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'; ?>">
                                                    <?php echo ucfirst($item['type']); ?>
                                                </span>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <?php echo htmlspecialchars($item['category_name']); ?>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <?php echo isset($item['user_name']) ? htmlspecialchars($item['user_name']) : 'Unknown User'; ?>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <?php echo htmlspecialchars(formatDate($item['date'])); ?>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                    <?php 
                                                        if ($item['status'] === 'open') echo 'bg-blue-100 text-blue-800';
                                                        else if ($item['status'] === 'closed') echo 'bg-gray-100 text-gray-800';
                                                        else if ($item['status'] === 'pending') echo 'bg-yellow-100 text-yellow-800';
                                                        else if ($item['status'] === 'rejected') echo 'bg-red-100 text-red-800';
                                                    ?>">
                                                    <?php echo ucfirst($item['status']); ?>
                                                </span>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                                <a href="../item-details.php?id=<?php echo $item['id']; ?>" class="text-blue-600 hover:text-blue-900 mr-3">View</a>
                                                <a href="manage-item.php?id=<?php echo $item['id']; ?>" class="text-indigo-600 hover:text-indigo-900">Manage</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </form>
                    
                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <div class="flex justify-center mt-8">
                            <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                                <?php if ($page > 1): ?>
                                    <a href="?type=<?php echo urlencode($item_type); ?>&category=<?php echo urlencode($category); ?>&search=<?php echo urlencode($search); ?>&date_from=<?php echo urlencode($date_from); ?>&date_to=<?php echo urlencode($date_to); ?>&location=<?php echo urlencode($location); ?>&status=<?php echo urlencode($status); ?>&page=<?php echo $page - 1; ?>" class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                                        <span class="sr-only">Previous</span>
                                        <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                            <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
                                        </svg>
                                    </a>
                                <?php endif; ?>
                                
                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <a href="?type=<?php echo urlencode($item_type); ?>&category=<?php echo urlencode($category); ?>&search=<?php echo urlencode($search); ?>&date_from=<?php echo urlencode($date_from); ?>&date_to=<?php echo urlencode($date_to); ?>&location=<?php echo urlencode($location); ?>&status=<?php echo urlencode($status); ?>&page=<?php echo $i; ?>" class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium <?php echo $page === $i ? 'text-blue-600 bg-blue-50' : 'text-gray-700 hover:bg-gray-50'; ?>">
                                        <?php echo $i; ?>
                                    </a>
                                <?php endfor; ?>
                                
                                <?php if ($page < $total_pages): ?>
                                    <a href="?type=<?php echo urlencode($item_type); ?>&category=<?php echo urlencode($category); ?>&search=<?php echo urlencode($search); ?>&date_from=<?php echo urlencode($date_from); ?>&date_to=<?php echo urlencode($date_to); ?>&location=<?php echo urlencode($location); ?>&status=<?php echo urlencode($status); ?>&page=<?php echo $page + 1; ?>" class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                                        <span class="sr-only">Next</span>
                                        <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                            <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
                                        </svg>
                                    </a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </main>
    
    <?php include('../includes/footer.php'); ?>
    <script src="../js/app.js"></script>
    <script>
        // Select all checkbox functionality
        document.getElementById('selectAll').addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.item-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
        });
    </script>
</body>
</html>