<header class="bg-gray-800 text-white shadow">
    <div class="container mx-auto px-4">
        <div class="flex justify-between items-center py-4">
            <div class="flex items-center">
                <a href="../index.php" class="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-blue-400" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd" />
                    </svg>
                    <span class="ml-2 text-xl font-bold"> LostLink -Admin</span>
                </a>
            </div>
            
            <div class="hidden md:flex items-center space-x-6">
                <a href="dashboard.php" class="text-gray-300 hover:text-white font-medium">Dashboard</a>
                <a href="items.php" class="text-gray-300 hover:text-white font-medium">Manage Items</a>
                <a href="users.php" class="text-gray-300 hover:text-white font-medium">Manage Users</a>
                <a href="categories.php" class="text-gray-300 hover:text-white font-medium">Categories</a>
                <a href="reports.php" class="text-gray-300 hover:text-white font-medium">Reports</a>
                
                <a href="../index.php" class="text-gray-300 hover:text-white font-medium">
                    <span class="flex items-center">
                        <span>Exit Admin</span>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                        </svg>
                    </span>
                </a>
            </div>
            
            <div class="flex items-center">
                <div class="relative group">
                    <button class="flex items-center focus:outline-none">
                        <span class="mr-1"><?php echo htmlspecialchars(getUserName()); ?></span>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                        </svg>
                    </button>
                    
                    <div class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg overflow-hidden z-20 hidden group-hover:block">
                        <a href="../profile.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Profile</a>
                        <a href="../logout.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Logout</a>
                    </div>
                </div>
                
                <button class="md:hidden ml-4 focus:outline-none" id="adminMenuToggle">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                </button>
            </div>
        </div>
        
        <!-- Mobile menu -->
        <div class="md:hidden hidden" id="adminMobileMenu">
            <div class="py-2 space-y-1 border-t border-gray-700">
                <a href="dashboard.php" class="block px-4 py-2 text-gray-300 hover:text-white">Dashboard</a>
                <a href="items.php" class="block px-4 py-2 text-gray-300 hover:text-white">Manage Items</a>
                <a href="user.php" class="block px-4 py-2 text-gray-300 hover:text-white">Manage Users</a>
                <a href="categories.php" class="block px-4 py-2 text-gray-300 hover:text-white">Categories</a>
                <a href="report.php" class="block px-4 py-2 text-gray-300 hover:text-white">Reports</a>
                <a href="../index.php" class="block px-4 py-2 text-gray-300 hover:text-white">Exit Admin</a>
            </div>
        </div>
    </div>
</header>

<script>
    // Mobile menu toggle
    document.getElementById('adminMenuToggle').addEventListener('click', function() {
        const mobileMenu = document.getElementById('adminMobileMenu');
        mobileMenu.classList.toggle('hidden');
    });
</script>