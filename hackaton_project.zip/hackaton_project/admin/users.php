<?php
session_start();
require_once('../includes/config.php');
require_once('../includes/auth.php');
require_once('../includes/functions.php');

// Restrict access to admins only
if (!isLoggedIn() || !isAdmin()) {
    header('Location: ../login.php');
    exit();
}

$conn = connectDB();

// Handle user actions (activate, deactivate, delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['user_id'])) {
    $user_id = (int) $_POST['user_id'];
    $action = $_POST['action'];

    if ($user_id !== $_SESSION['user_id']) { // Prevent admin from editing themselves
        if ($action === 'deactivate') {
            $stmt = $conn->prepare("UPDATE users SET status = 'inactive' WHERE id = ?");
            $stmt->execute([$user_id]);
        } elseif ($action === 'activate') {
            $stmt = $conn->prepare("UPDATE users SET status = 'active' WHERE id = ?");
            $stmt->execute([$user_id]);
        } elseif ($action === 'delete') {
            $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
        }
    }

    header('Location: manage-users.php');
    exit();
}

// Fetch all users
$stmt = $conn->query("SELECT id, name, email, user_type, role, status, created_at FROM users ORDER BY created_at DESC");
$users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('../includes/head.php'); ?>
    <title>Manage Users - Admin</title>
</head>
<body>
    <?php include('../admin/includes/admin-header.php'); ?>

    <main class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold mb-6">Manage Users</h1>

        <div class="bg-white shadow-md rounded-lg overflow-x-auto">
            <table class="min-w-full text-sm text-left text-gray-600">
                <thead class="bg-gray-100 text-xs uppercase text-gray-700">
                    <tr>
                        <th class="px-4 py-3">ID</th>
                        <th class="px-4 py-3">Name</th>
                        <th class="px-4 py-3">Email</th>
                        <th class="px-4 py-3">Type</th>
                        <th class="px-4 py-3">Role</th>
                        <th class="px-4 py-3">Status</th>
                        <th class="px-4 py-3">Joined</th>
                        <th class="px-4 py-3">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="px-4 py-3"><?php echo $user['id']; ?></td>
                            <td class="px-4 py-3"><?php echo htmlspecialchars($user['name']); ?></td>
                            <td class="px-4 py-3"><?php echo htmlspecialchars($user['email']); ?></td>
                            <td class="px-4 py-3"><?php echo htmlspecialchars($user['user_type']); ?></td>
                            <td class="px-4 py-3"><?php echo htmlspecialchars($user['role']); ?></td>
                            <td class="px-4 py-3">
                                <span class="<?php echo $user['status'] === 'active' ? 'text-green-600' : 'text-red-600'; ?>">
                                    <?php echo ucfirst($user['status']); ?>
                                </span>
                            </td>
                            <td class="px-4 py-3"><?php echo date('Y-m-d', strtotime($user['created_at'])); ?></td>
                            <td class="px-4 py-3 space-x-1">
                                <?php if ($user['id'] !== $_SESSION['user_id']): ?>
                                    <form method="POST" class="inline">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        <?php if ($user['status'] === 'active'): ?>
                                            <button type="submit" name="action" value="deactivate" class="bg-yellow-500 text-white px-2 py-1 rounded hover:bg-yellow-600">Deactivate</button>
                                        <?php else: ?>
                                            <button type="submit" name="action" value="activate" class="bg-green-500 text-white px-2 py-1 rounded hover:bg-green-600">Activate</button>
                                        <?php endif; ?>
                                        <button type="submit" name="action" value="delete" class="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600" onclick="return confirm('Are you sure you want to delete this user?')">Delete</button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-gray-400 italic">Your account</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>

    <?php include('../includes/footer.php'); ?>
</body>
</html>
