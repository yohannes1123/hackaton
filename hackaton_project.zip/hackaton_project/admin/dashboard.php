<?php
session_start();
require_once('../includes/config.php');
require_once('../includes/auth.php');
require_once('../includes/functions.php');
require_once('../includes/upload.php');

// Redirect if not admin
if (!isAdmin()) {
    header('Location: ../index.php');
    exit();
}

// Get dashboard stats
$stats = getAdminDashboardStats();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('../includes/head.php'); ?>
    <title>Admin Dashboard - Campus Finder</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include('includes/admin-header.php'); ?>
    
    <main class="container mx-auto px-4 py-8">
        <div class="mb-6">
            <h2 class="text-2xl font-bold mb-4">Admin Dashboard</h2>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <!-- Total Items Card -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-start justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-500 uppercase">Total Items</p>
                            <p class="text-3xl font-bold text-gray-900"><?php echo $stats['total_items']; ?></p>
                        </div>
                        <div class="p-3 rounded-full bg-blue-100 text-blue-600">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                            </svg>
                        </div>
                    </div>
                    <div class="mt-4 flex items-center">
                        <span class="text-xs font-medium text-gray-500">Updated today</span>
                    </div>
                </div>
                
                <!-- Lost Items Card -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-start justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-500 uppercase">Lost Items</p>
                            <p class="text-3xl font-bold text-red-600"><?php echo $stats['lost_items']; ?></p>
                        </div>
                        <div class="p-3 rounded-full bg-red-100 text-red-600">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                            </svg>
                        </div>
                    </div>
                    <div class="mt-4 flex items-center">
                        <span class="text-sm font-medium <?php echo $stats['lost_items_change'] >= 0 ? 'text-green-600' : 'text-red-600'; ?>">
                            <?php echo $stats['lost_items_change'] >= 0 ? '+' : ''; ?><?php echo $stats['lost_items_change']; ?>%
                        </span>
                        <span class="text-xs font-medium text-gray-500 ml-2">from last week</span>
                    </div>
                </div>
                
                <!-- Found Items Card -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-start justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-500 uppercase">Found Items</p>
                            <p class="text-3xl font-bold text-green-600"><?php echo $stats['found_items']; ?></p>
                        </div>
                        <div class="p-3 rounded-full bg-green-100 text-green-600">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                            </svg>
                        </div>
                    </div>
                    <div class="mt-4 flex items-center">
                        <span class="text-sm font-medium <?php echo $stats['found_items_change'] >= 0 ? 'text-green-600' : 'text-red-600'; ?>">
                            <?php echo $stats['found_items_change'] >= 0 ? '+' : ''; ?><?php echo $stats['found_items_change']; ?>%
                        </span>
                        <span class="text-xs font-medium text-gray-500 ml-2">from last week</span>
                    </div>
                </div>
                
                <!-- Return Rate Card -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-start justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-500 uppercase">Return Rate</p>
                            <p class="text-3xl font-bold text-purple-600"><?php echo $stats['return_rate']; ?>%</p>
                        </div>
                        <div class="p-3 rounded-full bg-purple-100 text-purple-600">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                            </svg>
                        </div>
                    </div>
                    <div class="mt-4 flex items-center">
                        <span class="text-sm font-medium <?php echo $stats['return_rate_change'] >= 0 ? 'text-green-600' : 'text-red-600'; ?>">
                            <?php echo $stats['return_rate_change'] >= 0 ? '+' : ''; ?><?php echo $stats['return_rate_change']; ?>%
                        </span>
                        <span class="text-xs font-medium text-gray-500 ml-2">from last month</span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="grid md:grid-cols-2 gap-6 mb-8">
            <!-- Recent Items Chart -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-bold mb-4">Item Reports (Last 30 Days)</h3>
                <canvas id="itemsChart" height="250"></canvas>
            </div>
            
            <!-- Category Distribution Chart -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-bold mb-4">Items by Category</h3>
                <canvas id="categoryChart" height="250"></canvas>
            </div>
        </div>
        
        <div class="mb-8">
            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <div class="px-6 py-4 bg-gray-50 border-b">
                    <h3 class="text-lg font-bold">Recent Reports</h3>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($stats['recent_items'] as $item): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($item['item_name']); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $item['type'] === 'lost' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'; ?>">
                                            <?php echo ucfirst($item['type']); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo htmlspecialchars($item['category_name']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo htmlspecialchars($item['user_name']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo htmlspecialchars(formatDate($item['date'])); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $item['status'] === 'open' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'; ?>">
                                            <?php echo ucfirst($item['status']); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        <a href="../item-details.php?id=<?php echo $item['id']; ?>" class="text-blue-600 hover:text-blue-900 mr-3">View</a>
                                        <a href="manage-item.php?id=<?php echo $item['id']; ?>" class="text-indigo-600 hover:text-indigo-900">Manage</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="px-6 py-4 bg-gray-50 border-t">
                    <a href="items.php" class="text-blue-600 hover:text-blue-800">View All Items</a>
                </div>
            </div>
        </div>
    </main>
    
    <?php include('../includes/footer.php'); ?>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Items chart
        const itemsChartData = <?php echo json_encode($stats['items_by_day']); ?>;
        const itemsChartLabels = itemsChartData.map(item => item.date);
        const lostData = itemsChartData.map(item => item.lost);
        const foundData = itemsChartData.map(item => item.found);
        
        new Chart(document.getElementById('itemsChart'), {
            type: 'line',
            data: {
                labels: itemsChartLabels,
                datasets: [
                    {
                        label: 'Lost Items',
                        data: lostData,
                        borderColor: '#EF4444',
                        backgroundColor: 'rgba(239, 68, 68, 0.1)',
                        tension: 0.3,
                        fill: true
                    },
                    {
                        label: 'Found Items',
                        data: foundData,
                        borderColor: '#10B981',
                        backgroundColor: 'rgba(16, 185, 129, 0.1)',
                        tension: 0.3,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });
        
        // Category chart
        const categoryData = <?php echo json_encode($stats['items_by_category']); ?>;
        const categoryLabels = categoryData.map(item => item.name);
        const categoryValues = categoryData.map(item => item.count);
        const categoryColors = [
            'rgba(59, 130, 246, 0.8)',
            'rgba(16, 185, 129, 0.8)',
            'rgba(249, 115, 22, 0.8)',
            'rgba(236, 72, 153, 0.8)',
            'rgba(139, 92, 246, 0.8)',
            'rgba(75, 85, 99, 0.8)',
            'rgba(245, 158, 11, 0.8)',
            'rgba(6, 182, 212, 0.8)',
            'rgba(248, 113, 113, 0.8)',
            'rgba(167, 139, 250, 0.8)'
        ];
        
        new Chart(document.getElementById('categoryChart'), {
            type: 'doughnut',
            data: {
                labels: categoryLabels,
                datasets: [{
                    data: categoryValues,
                    backgroundColor: categoryColors.slice(0, categoryLabels.length),
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'right',
                    }
                },
                cutout: '60%'
            }
        });
    });
    </script>
</body>
</html>