<?php
session_start();
require_once('../includes/auth.php');
require_once('../includes/functions.php');

if (!isAdmin()) {
    header('Location: ../index.php');
    exit();
}

// Handle new category addition
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['category_name'])) {
    $category_name = trim($_POST['category_name']);

    if (!empty($category_name)) {
        $conn = connectDB();
        $stmt = $conn->prepare("INSERT INTO item_categories (name) VALUES (?)");

        try {
            $stmt->execute([$category_name]);
            $message = "Category '$category_name' added successfully.";
        } catch (PDOException $e) {
            $message = "Error: " . $e->getMessage();
        }
    }
}

// Fetch all categories
$conn = connectDB();
$stmt = $conn->query("SELECT * FROM item_categories ORDER BY name ASC");
$categories = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('../includes/head.php'); ?>
    <title>Manage Categories - Admin</title>
</head>
<body>
    <?php include('../admin/includes/admin-header.php'); ?>

    <main class="container mx-auto px-4 py-8">
        <div class="max-w-2xl mx-auto">
            <h1 class="text-2xl font-bold mb-4">Manage Categories</h1>

            <?php if ($message): ?>
                <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="mb-6">
                <div class="flex items-center space-x-4">
                    <input type="text" name="category_name" placeholder="New Category Name" class="flex-grow border rounded px-4 py-2 focus:outline-none" required>
                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Add</button>
                </div>
            </form>

            <div class="bg-white rounded shadow">
                <table class="w-full table-auto">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="text-left px-4 py-2">#</th>
                            <th class="text-left px-4 py-2">Category Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($categories as $index => $category): ?>
                            <tr class="border-t">
                                <td class="px-4 py-2"><?php echo $index + 1; ?></td>
                                <td class="px-4 py-2"><?php echo htmlspecialchars($category['name']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($categories)): ?>
                            <tr>
                                <td colspan="2" class="px-4 py-4 text-center text-gray-500">No categories found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <?php include('../includes/footer.php'); ?>
</body>
</html>
