<?php
session_start();
require_once('../includes/auth.php');
require_once('../includes/functions.php');
//require_once('../includes/update.php');

// Restrict access to admins only
if (!isLoggedIn() || !isAdmin()) {
    header('Location: ../login.php');
    exit();
}

// Fetch reports (claims and resolved items for example)
$conn = connectDB();

$reports = [];
$stmt = $conn->prepare("SELECT ic.id, ic.message, ic.status, ic.created_at,
                               u.name AS user_name,
                               i.item_name, i.type AS item_type
                        FROM item_claims ic
                        JOIN users u ON ic.user_id = u.id
                        JOIN items i ON ic.item_id = i.id
                        ORDER BY ic.created_at DESC");
$stmt->execute();
$reports = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('../includes/head.php'); ?>
    <title>Admin - Reports</title>
</head>
<body>
    <?php include('../admin/includes/admin-header.php'); ?>

    <main class="container mx-auto px-4 py-8">
        <h1 class="text-2xl font-bold mb-6">User Claims & Reports</h1>

        <div class="bg-white shadow rounded-lg overflow-x-auto">
            <table class="min-w-full text-sm text-left">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2">User</th>
                        <th class="px-4 py-2">Item</th>
                        <th class="px-4 py-2">Type</th>
                        <th class="px-4 py-2">Message</th>
                        <th class="px-4 py-2">Status</th>
                        <th class="px-4 py-2">Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($reports)): ?>
                        <tr>
                            <td colspan="6" class="text-center px-4 py-4 text-gray-500">No reports found.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($reports as $report): ?>
                            <tr class="border-b">
                                <td class="px-4 py-2"><?php echo htmlspecialchars($report['user_name']); ?></td>
                                <td class="px-4 py-2"><?php echo htmlspecialchars($report['item_name']); ?></td>
                                <td class="px-4 py-2 capitalize"><?php echo htmlspecialchars($report['item_type']); ?></td>
                                <td class="px-4 py-2"><?php echo htmlspecialchars($report['message']); ?></td>
                                <td class="px-4 py-2"><?php echo htmlspecialchars($report['status']); ?></td>
                                <td class="px-4 py-2"><?php echo htmlspecialchars(date('M d, Y H:i', strtotime($report['created_at']))); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

    <?php include('../includes/footer.php'); ?>
    <script src="../js/app.js"></script>
</body>
</html>
