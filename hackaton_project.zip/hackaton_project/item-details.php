<?php
session_start();
require_once('includes/config.php');
require_once('includes/auth.php');
require_once('includes/functions.php');
require_once('includes/upload.php');
// Redirect to login if not authenticated
if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

// Get item ID from URL
$item_id = $_GET['id'] ?? 0;

// Process claim action
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    if ($action === 'claim') {
        // Process claim request
        $claim_message = $_POST['claim_message'] ?? '';
        $result = claimItem($item_id, $_SESSION['user_id'], $claim_message);
        
        if ($result['success']) {
            $message = 'Claim submitted successfully. The item owner will be notified.';
            $message_type = 'success';
        } else {
            $message = $result['message'];
            $message_type = 'error';
        }
    } elseif ($action === 'mark_resolved') {
        // Mark item as resolved/found
        $result = markItemResolved($item_id, $_SESSION['user_id']);
        
        if ($result['success']) {
            $message = 'Item has been marked as returned/found.';
            $message_type = 'success';
        } else {
            $message = $result['message'];
            $message_type = 'error';
        }
    }
}

// Get item details
$item = getItemDetails($item_id);

// Check if item exists
if (!$item) {
    header('Location: index.php');
    exit();
}

// Get claims for this item if the user is the owner
$claims = [];
if ($item['user_id'] == $_SESSION['user_id']) {
    $claims = getItemClaims($item_id);
}

// Determine if the current user can claim this item
$can_claim = ($item['type'] === 'found' && $item['user_id'] != $_SESSION['user_id'] && $item['status'] === 'open');

// Determine if the current user can mark as resolved
$can_resolve = ($item['user_id'] == $_SESSION['user_id'] && $item['status'] === 'open');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('includes/head.php'); ?>
    <title>Item Details - Campus Finder</title>
    <style>
        .photo-container img {
            transition: transform 0.3s ease;
        }
        .photo-container:hover img {
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <?php include('includes/header.php'); ?>
    
    <main class="container mx-auto px-4 py-8">
        <div class="max-w-4xl mx-auto">
            <!-- Navigation and Status -->
            <div class="flex justify-between items-center mb-6">
                <a href="javascript:history.back()" class="text-blue-600 hover:text-blue-800">
                    <span class="inline-flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                        </svg>
                        Back
                    </span>
                </a>
                
                <span class="rounded-full px-4 py-1 font-semibold <?php echo $item['status'] === 'open' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'; ?>">
                    <?php echo $item['status'] === 'open' ? 'Open' : 'Closed'; ?>
                </span>
            </div>
            
            <?php if ($message): ?>
                <div class="bg-<?php echo $message_type === 'success' ? 'green' : 'red'; ?>-100 border-l-4 border-<?php echo $message_type === 'success' ? 'green' : 'red'; ?>-500 text-<?php echo $message_type === 'success' ? 'green' : 'red'; ?>-700 p-4 mb-6" role="alert">
                    <p><?php echo htmlspecialchars($message); ?></p>
                </div>
            <?php endif; ?>
            
            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <!-- Item Header -->
                <div class="bg-gray-50 p-6 border-b">
                    <div class="flex justify-between items-start">
                        <div>
                            <h2 class="text-2xl font-bold"><?php echo htmlspecialchars($item['item_name']); ?></h2>
                            <p class="text-gray-600">
                                <?php echo $item['type'] === 'lost' ? 'Lost on ' : 'Found on '; ?>
                                <?php echo htmlspecialchars(formatDate($item['date'])); ?>
                            </p>
                        </div>
                        <span class="rounded-full px-3 py-1 text-sm font-semibold 
                            <?php echo $item['type'] === 'lost' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'; ?>">
                            <?php echo $item['type'] === 'lost' ? 'Lost' : 'Found'; ?>
                        </span>
                    </div>
                </div>
                
                <!-- Item Content -->
                <div class="p-6">
                    <div class="grid md:grid-cols-2 gap-8">
                        <!-- Left Column: Photo or Placeholder -->
                        <div class="photo-container overflow-hidden rounded-lg border">
                            <?php if (!empty($item['photo'])): ?>
                                <img src="uploads/<?php echo htmlspecialchars($item['photo']); ?>" alt="<?php echo htmlspecialchars($item['item_name']); ?>" class="w-full h-auto object-cover">
                            <?php else: ?>
                                <div class="w-full h-64 bg-gray-100 flex items-center justify-center">
                                    <span class="text-gray-400">No image available</span>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Right Column: Details -->
                        <div>
                            <h3 class="text-lg font-semibold mb-4">Item Details</h3>
                            
                            <div class="space-y-3">
                                <div>
                                    <p class="text-sm text-gray-500">Category</p>
                                    <p class="font-medium"><?php echo htmlspecialchars($item['category_name']); ?></p>
                                </div>
                                
                                <div>
                                    <p class="text-sm text-gray-500">Location</p>
                                    <p class="font-medium"><?php echo htmlspecialchars(formatLocation($item['location'])); ?></p>
                                </div>
                                
                                <?php if ($item['type'] === 'found' && isset($item['turned_in']) && $item['turned_in']): ?>
                                    <div>
                                        <p class="text-sm text-gray-500">Turned In At</p>
                                        <p class="font-medium"><?php echo htmlspecialchars(formatTurnedInLocation($item['turned_in_location'])); ?></p>
                                    </div>
                                <?php endif; ?>
                                
                                <div>
                                    <p class="text-sm text-gray-500">Date <?php echo $item['type'] === 'lost' ? 'Lost' : 'Found'; ?></p>
                                    <p class="font-medium"><?php echo htmlspecialchars(formatDate($item['date'])); ?></p>
                                </div>
                                
                                <div>
                                    <p class="text-sm text-gray-500">Report Date</p>
                                    <p class="font-medium"><?php echo htmlspecialchars(formatDateTime($item['created_at'])); ?></p>
                                </div>
                                
                                <div>
                                    <p class="text-sm text-gray-500">Description</p>
                                    <p><?php echo htmlspecialchars($item['description']); ?></p>
                                </div>
                            </div>
                            
                            <?php if ($can_claim): ?>
                                <div class="mt-6">
                                    <button id="claimButton" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md focus:outline-none focus:shadow-outline transition duration-300">
                                        This Might Be Mine
                                    </button>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($can_resolve): ?>
                                <div class="mt-6">
                                    <form method="POST" action="item-details.php?id=<?php echo htmlspecialchars($item_id); ?>">
                                        <input type="hidden" name="action" value="mark_resolved">
                                        <button type="submit" class="w-full bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-md focus:outline-none focus:shadow-outline transition duration-300">
                                            Mark as <?php echo $item['type'] === 'lost' ? 'Found' : 'Returned to Owner'; ?>
                                        </button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Claims Section (only visible to item owner) -->
                    <?php if (!empty($claims)): ?>
                        <div class="mt-10 border-t pt-6">
                            <h3 class="text-lg font-semibold mb-4">Claims (<?php echo count($claims); ?>)</h3>
                            
                            <div class="space-y-4">
                                <?php foreach ($claims as $claim): ?>
                                    <div class="bg-gray-50 p-4 rounded-lg">
                                        <div class="flex justify-between">
                                            <div>
                                                <p class="font-medium"><?php echo htmlspecialchars($claim['user_name']); ?></p>
                                                <p class="text-sm text-gray-500"><?php echo htmlspecialchars(formatDateTime($claim['created_at'])); ?></p>
                                            </div>
                                            <div>
                                                <a href="message.php?user=<?php echo htmlspecialchars($claim['user_id']); ?>&item=<?php echo htmlspecialchars($item_id); ?>" class="inline-block bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium py-1 px-3 rounded-md focus:outline-none focus:shadow-outline transition duration-300">
                                                    Contact
                                                </a>
                                            </div>
                                        </div>
                                        <p class="mt-2"><?php echo htmlspecialchars($claim['message']); ?></p>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
    
    <!-- Claim Modal -->
    <div id="claimModal" class=" fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg shadow-xl max-w-md w-full mx-4">
            <div class="p-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-xl font-bold">Claim This Item</h3>
                    <button id="closeModal" class="text-gray-500 hover:text-gray-700">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>
                
                <p class="mb-4">To claim this item, please provide some identifying information that only the true owner would know.</p>
                
                <form method="POST" action="item-details.php?id=<?php echo htmlspecialchars($item_id); ?>">
                    <input type="hidden" name="action" value="claim">
                    
                    <div class="mb-4">
                        <label for="claim_message" class="block text-gray-700 text-sm font-bold mb-2">Describe the item in detail or provide proof of ownership</label>
                        <textarea id="claim_message" name="claim_message" rows="4" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500" required></textarea>
                    </div>
                    
                    <div class="flex justify-end">
                        <button type="button" id="cancelClaim" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded-md focus:outline-none focus:shadow-outline transition duration-300 mr-2">
                            Cancel
                        </button>
                        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md focus:outline-none focus:shadow-outline transition duration-300">
                            Submit Claim
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <?php include('includes/footer.php'); ?>
    <script src="js/app.js"></script>
    <script>
        // Claim modal functionality
        const claimButton = document.getElementById('claimButton');
        const claimModal = document.getElementById('claimModal');
        const closeModal = document.getElementById('closeModal');
        const cancelClaim = document.getElementById('cancelClaim');
        
        if (claimButton) {
            claimButton.addEventListener('click', () => {
                claimModal.classList.remove('hidden');
                document.body.style.overflow = 'hidden';
            });
        }
        
        if (closeModal) {
            closeModal.addEventListener('click', () => {
                claimModal.classList.add('hidden');
                document.body.style.overflow = 'auto';
            });
        }
        
        if (cancelClaim) {
            cancelClaim.addEventListener('click', () => {
                claimModal.classList.add('hidden');
                document.body.style.overflow = 'auto';
            });
        }
    </script>
</body>
</html>