<?php
session_start();
require_once('includes/config.php');
require_once('includes/auth.php');
require_once('includes/functions.php');
require_once('includes/upload.php');

// Redirect to login if not authenticated
if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

// Get filter parameters
$item_type = $_GET['type'] ?? 'all'; // all, lost, found
$category = $_GET['category'] ?? '';
$search = $_GET['search'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$location = $_GET['location'] ?? '';
$status = $_GET['status'] ?? 'open'; // open, closed, all

// Get categories for filter
$categories = getItemCategories();

// Get paginated results
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 12;
$offset = ($page - 1) * $per_page;

// Get items
$result = getFilteredItems($item_type, $category, $search, $date_from, $date_to, $location, $status, $per_page, $offset);
$items = $result['items'];
$total_items = $result['total'];
$total_pages = ceil($total_items / $per_page);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('includes/head.php'); ?>
    <title>Browse Items - Campus Finder</title>
</head>
<body>
    <?php include('includes/header.php'); ?>
    
    <main class="container mx-auto px-4 py-8">
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 class="text-2xl font-bold mb-6">Browse Lost & Found Items</h2>
            
            <form method="GET" action="browse.php" class="mb-6">
                <div class="grid md:grid-cols-3 gap-4">
                    <div>
                        <label for="type" class="block text-gray-700 text-sm font-bold mb-2">Item Type</label>
                        <select id="type" name="type" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500">
                            <option value="all" <?php echo $item_type === 'all' ? 'selected' : ''; ?>>All Items</option>
                            <option value="lost" <?php echo $item_type === 'lost' ? 'selected' : ''; ?>>Lost Items</option>
                            <option value="found" <?php echo $item_type === 'found' ? 'selected' : ''; ?>>Found Items</option>
                        </select>
                    </div>
                    
                    <div>
                        <label for="category" class="block text-gray-700 text-sm font-bold mb-2">Category</label>
                        <select id="category" name="category" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500">
                            <option value="">All Categories</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo htmlspecialchars($cat['id']); ?>" <?php echo $category == $cat['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div>
                        <label for="location" class="block text-gray-700 text-sm font-bold mb-2">Location</label>
                        <select id="location" name="location" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500">
                            <option value="">All Locations</option>
                            <option value="library" <?php echo $location === 'library' ? 'selected' : ''; ?>>Library</option>
                            <option value="student_center" <?php echo $location === 'student_center' ? 'selected' : ''; ?>>Student Center</option>
                            <option value="dining_hall" <?php echo $location === 'dining_hall' ? 'selected' : ''; ?>>Dining Hall</option>
                            <option value="gym" <?php echo $location === 'gym' ? 'selected' : ''; ?>>Gymnasium</option>
                            <option value="dorm" <?php echo $location === 'dorm' ? 'selected' : ''; ?>>Dormitory</option>
                            <option value="classroom" <?php echo $location === 'classroom' ? 'selected' : ''; ?>>Classroom</option>
                            <option value="outdoor" <?php echo $location === 'outdoor' ? 'selected' : ''; ?>>Outdoor Areas</option>
                            <option value="parking" <?php echo $location === 'parking' ? 'selected' : ''; ?>>Parking Lot</option>
                            <option value="other" <?php echo $location === 'other' ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>
                </div>
                
                <div class="grid md:grid-cols-3 gap-4 mt-4">
                    <div>
                        <label for="search" class="block text-gray-700 text-sm font-bold mb-2">Search</label>
                        <input type="text" id="search" name="search" value="<?php echo htmlspecialchars($search); ?>" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500" placeholder="Search by keywords...">
                    </div>
                    
                    <div>
                        <label for="date_from" class="block text-gray-700 text-sm font-bold mb-2">Date From</label>
                        <input type="date" id="date_from" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500">
                    </div>
                    
                    <div>
                        <label for="date_to" class="block text-gray-700 text-sm font-bold mb-2">Date To</label>
                        <input type="date" id="date_to" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500">
                    </div>
                </div>
                
                <div class="flex justify-between items-center mt-4">
                    <div>
                        <label for="status" class="block text-gray-700 text-sm font-bold mb-2">Status</label>
                        <select id="status" name="status" class="shadow appearance-none border rounded w-40 py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500">
                            <option value="open" <?php echo $status === 'open' ? 'selected' : ''; ?>>Open</option>
                            <option value="closed" <?php echo $status === 'closed' ? 'selected' : ''; ?>>Closed</option>
                            <option value="all" <?php echo $status === 'all' ? 'selected' : ''; ?>>All</option>
                        </select>
                    </div>
                    
                    <div class="mt-6">
                        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md focus:outline-none focus:shadow-outline transition duration-300">
                            Filter Results
                        </button>
                        <a href="browse.php" class="ml-2 text-blue-600 hover:text-blue-800">Reset</a>
                    </div>
                </div>
            </form>
            
            <?php if (empty($items)): ?>
                <div class="text-center py-8">
                    <p class="text-lg text-gray-600">No items found matching your criteria.</p>
                    <p class="mt-2">Try adjusting your filters or check back later.</p>
                </div>
            <?php else: ?>
                <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php foreach ($items as $item): ?>
                        <div class="bg-white border rounded-lg overflow-hidden hover:shadow-lg transition duration-300">
                            <div class="p-4 border-b">
                                <div class="flex justify-between items-start">
                                    <div>
                                        <h3 class="font-bold text-lg"><?php echo htmlspecialchars($item['item_name']); ?></h3>
                                        <p class="text-sm text-gray-600">
                                            <?php echo $item['type'] === 'lost' ? 'Lost on ' : 'Found on '; ?>
                                            <?php echo htmlspecialchars(formatDate($item['date'])); ?>
                                        </p>
                                    </div>
                                    <span class="rounded-full px-3 py-1 text-xs font-semibold 
                                        <?php echo $item['type'] === 'lost' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'; ?>">
                                        <?php echo $item['type'] === 'lost' ? 'Lost' : 'Found'; ?>
                                    </span>
                                </div>
                            </div>
                            
                            <?php if (!empty($item['photo'])): ?>
                                <img src="uploads/<?php echo htmlspecialchars($item['photo']); ?>" alt="<?php echo htmlspecialchars($item['item_name']); ?>" class="w-full h-48 object-cover">
                            <?php else: ?>
                                <div class="w-full h-48 bg-gray-100 flex items-center justify-center">
                                    <span class="text-gray-400">No image available</span>
                                </div>
                            <?php endif; ?>
                            
                            <div class="p-4">
                                <p class="text-sm mb-2">
                                    <span class="font-semibold">Category:</span> <?php echo htmlspecialchars($item['category_name']); ?>
                                </p>
                                <p class="text-sm mb-2">
                                    <span class="font-semibold">Location:</span> <?php echo htmlspecialchars(formatLocation($item['location'])); ?>
                                </p>
                                <p class="text-sm mb-4 line-clamp-2">
                                    <span class="font-semibold">Description:</span> <?php echo htmlspecialchars($item['description']); ?>
                                </p>
                                
                                <a href="item-details.php?id=<?php echo htmlspecialchars($item['id']); ?>" class="block text-center bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition duration-300">
                                    View Details
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <div class="flex justify-center mt-8">
                        <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                            <?php if ($page > 1): ?>
                                <a href="?type=<?php echo urlencode($item_type); ?>&category=<?php echo urlencode($category); ?>&search=<?php echo urlencode($search); ?>&date_from=<?php echo urlencode($date_from); ?>&date_to=<?php echo urlencode($date_to); ?>&location=<?php echo urlencode($location); ?>&status=<?php echo urlencode($status); ?>&page=<?php echo $page - 1; ?>" class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                                    <span class="sr-only">Previous</span>
                                    <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                        <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
                                    </svg>
                                </a>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <a href="?type=<?php echo urlencode($item_type); ?>&category=<?php echo urlencode($category); ?>&search=<?php echo urlencode($search); ?>&date_from=<?php echo urlencode($date_from); ?>&date_to=<?php echo urlencode($date_to); ?>&location=<?php echo urlencode($location); ?>&status=<?php echo urlencode($status); ?>&page=<?php echo $i; ?>" class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium <?php echo $page === $i ? 'text-blue-600 bg-blue-50' : 'text-gray-700 hover:bg-gray-50'; ?>">
                                    <?php echo $i; ?>
                                </a>
                            <?php endfor; ?>
                            
                            <?php if ($page < $total_pages): ?>
                                <a href="?type=<?php echo urlencode($item_type); ?>&category=<?php echo urlencode($category); ?>&search=<?php echo urlencode($search); ?>&date_from=<?php echo urlencode($date_from); ?>&date_to=<?php echo urlencode($date_to); ?>&location=<?php echo urlencode($location); ?>&status=<?php echo urlencode($status); ?>&page=<?php echo $page + 1; ?>" class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                                    <span class="sr-only">Next</span>
                                    <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                        <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
                                    </svg>
                                </a>
                            <?php endif; ?>
                        </nav>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </main>
    
    <?php include('includes/footer.php'); ?>
    <script src="js/app.js"></script>
</body>
</html>