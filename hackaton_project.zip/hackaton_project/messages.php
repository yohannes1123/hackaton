<?php
session_start();
require_once('includes/config.php');
require_once('includes/auth.php');
require_once('includes/functions.php');

// Redirect to login if not authenticated
if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

// Get current user's conversations
$conversations = getUserConversations($_SESSION['user_id']);

// Get messages for a specific conversation if requested
$conversation_id = isset($_GET['conversation']) ? (int)$_GET['conversation'] : 0;
$other_user = null;
$messages = [];
$item = null;

if ($conversation_id > 0) {
    // Get conversation details
    $conversation = getConversationDetails($conversation_id, $_SESSION['user_id']);
    
    if (!$conversation) {
        header('Location: messages.php');
        exit();
    }
    
    $other_user = $conversation['other_user'];
    $item = $conversation['item'];
    $messages = getConversationMessages($conversation_id);
    
    // Mark messages as read
    markMessagesAsRead($conversation_id, $_SESSION['user_id']);
}

// Process message submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message']) && $conversation_id > 0) {
    $message_text = trim($_POST['message']);
    
    if (!empty($message_text)) {
        sendMessage($conversation_id, $_SESSION['user_id'], $message_text);
        
        // Redirect to avoid form resubmission
        header('Location: messages.php?conversation=' . $conversation_id);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('includes/head.php'); ?>
    <title>Messages - Campus Finder</title>
    <style>
        .message-container {
            max-height: 400px;
            overflow-y: auto;
        }
        
        .message-bubble {
            max-width: 75%;
            word-wrap: break-word;
        }
    </style>
</head>
<body>
    <?php include('includes/header.php'); ?>
    
    <main class="container mx-auto px-4 py-8">
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="md:flex">
                <!-- Conversations List -->
                <div class="md:w-1/3 border-r">
                    <div class="p-4 bg-gray-50 border-b">
                        <h2 class="text-lg font-bold">Conversations</h2>
                    </div>
                    
                    <div class="divide-y overflow-y-auto" style="max-height: 600px;">
                        <?php if (empty($conversations)): ?>
                            <div class="p-4 text-center text-gray-500">
                                <p>No conversations yet.</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($conversations as $conv): ?>
                                <a href="messages.php?conversation=<?php echo $conv['id']; ?>" class="block p-4 hover:bg-gray-50 transition <?php echo ($conversation_id == $conv['id']) ? 'bg-blue-50' : ''; ?>">
                                    <div class="flex justify-between items-start">
                                        <div>
                                            <p class="font-medium"><?php echo htmlspecialchars($conv['other_user_name']); ?></p>
                                            <p class="text-sm text-gray-500">
                                                <?php echo htmlspecialchars($conv['item_name']); ?>
                                                <span class="text-xs px-2 py-0.5 rounded-full <?php echo $conv['item_type'] === 'lost' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'; ?>">
                                                    <?php echo $conv['item_type'] === 'lost' ? 'Lost' : 'Found'; ?>
                                                </span>
                                            </p>
                                        </div>
                                        
                                        <?php if ($conv['unread_count'] > 0): ?>
                                            <span class="bg-blue-600 text-white text-xs font-medium px-2 py-0.5 rounded-full">
                                                <?php echo $conv['unread_count']; ?>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <p class="text-sm text-gray-600 mt-1 truncate">
                                        <?php echo htmlspecialchars($conv['last_message']); ?>
                                    </p>
                                    
                                    <p class="text-xs text-gray-500 mt-1">
                                        <?php echo formatDateTime($conv['last_message_time']); ?>
                                    </p>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Messages Area -->
                <div class="md:w-2/3">
                    <?php if ($conversation_id > 0 && $other_user): ?>
                        <!-- Conversation Header -->
                        <div class="p-4 bg-gray-50 border-b flex justify-between items-center">
                            <div>
                                <h2 class="font-bold"><?php echo htmlspecialchars($other_user['name']); ?></h2>
                                <?php if ($item): ?>
                                    <p class="text-sm text-gray-600">
                                        <span class="font-medium">Re:</span> <?php echo htmlspecialchars($item['name']); ?>
                                        <a href="item-details.php?id=<?php echo $item['id']; ?>" class="text-blue-600 hover:text-blue-800 ml-1">[View Item]</a>
                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <!-- Messages -->
                        <div class="p-4 message-container" id="messageContainer">
                            <?php if (empty($messages)): ?>
                                <div class="text-center text-gray-500 py-8">
                                    <p>No messages yet. Start the conversation!</p>
                                </div>
                            <?php else: ?>
                                <div class="space-y-4">
                                    <?php foreach ($messages as $msg): ?>
                                        <?php $is_mine = $msg['sender_id'] == $_SESSION['user_id']; ?>
                                        
                                        <div class="flex <?php echo $is_mine ? 'justify-end' : 'justify-start'; ?>">
                                            <div class="message-bubble rounded-lg p-3 <?php echo $is_mine ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-800'; ?>">
                                                <p><?php echo nl2br(htmlspecialchars($msg['message'])); ?></p>
                                                <p class="text-xs <?php echo $is_mine ? 'text-blue-200' : 'text-gray-500'; ?> text-right mt-1">
                                                    <?php echo formatDateTime($msg['created_at']); ?>
                                                </p>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Message Form -->
                        <div class="p-4 border-t">
                            <form method="POST" action="messages.php?conversation=<?php echo $conversation_id; ?>">
                                <div class="flex">
                                    <textarea name="message" rows="3" class="flex-grow shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-blue-500" placeholder="Type your message..." required></textarea>
                                    
                                    <button type="submit" class="ml-2 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md focus:outline-none focus:shadow-outline transition duration-300">
                                        Send
                                    </button>
                                </div>
                            </form>
                        </div>
                    <?php else: ?>
                        <div class="flex items-center justify-center h-full p-8">
                            <div class="text-center">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-16 w-16 mx-auto text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                                </svg>
                                <h3 class="text-lg font-medium text-gray-900">No conversation selected</h3>
                                <p class="mt-2 text-gray-600">Select a conversation from the list or start a new one from an item page.</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
    
    <?php include('includes/footer.php'); ?>
    <script src="js/app.js"></script>
    <?php if ($conversation_id > 0): ?>
    <script>
        // Scroll to bottom of message container
        const messageContainer = document.getElementById('messageContainer');
        if (messageContainer) {
            messageContainer.scrollTop = messageContainer.scrollHeight;
        }
    </script>
    <?php endif; ?>
</body>
</html>