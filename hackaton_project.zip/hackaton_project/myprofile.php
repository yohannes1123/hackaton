<?php
session_start();
require_once('includes/config.php');
require_once('includes/auth.php');
require_once('includes/functions.php');
require_once('includes/upload.php');

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$items = getUserItems($user_id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('includes/head.php'); ?>
    <title>My Reports - LostLink</title>
</head>
<body>
    <?php include('includes/header.php'); ?>

    <main class="container mx-auto px-4 py-8">
        <div class="max-w-4xl mx-auto">
            <h1 class="text-3xl font-bold mb-6">My Reports</h1>

            <?php if (empty($items)): ?>
                <div class="bg-yellow-50 border-l-4 border-yellow-400 text-yellow-700 p-4 mb-6">
                    <p>You haven't submitted any lost or found reports yet.</p>
                    <p class="mt-2">
                        <a href="report-lost.php" class="text-blue-600 underline">Report a Lost Item</a> or 
                        <a href="report-found.php" class="text-blue-600 underline">Report a Found Item</a>.
                    </p>
                </div>
            <?php else: ?>
                <div class="grid gap-6">
                    <?php foreach ($items as $item): ?>
                        <div class="bg-white shadow rounded-lg p-4 flex flex-col md:flex-row items-center md:items-start">
                            <div class="w-full md:w-32 h-32 flex-shrink-0 mb-4 md:mb-0 md:mr-6 border rounded overflow-hidden">
                                <?php if (!empty($item['photo'])): ?>
                                    <img src="uploads/<?php echo htmlspecialchars($item['photo']); ?>" alt="Item Photo" class="w-full h-full object-cover">
                                <?php else: ?>
                                    <div class="w-full h-full flex items-center justify-center bg-gray-100 text-gray-400 text-sm">No Image</div>
                                <?php endif; ?>
                            </div>

                            <div class="flex-1 w-full">
                                <h2 class="text-xl font-bold mb-1"><?php echo htmlspecialchars($item['item_name']); ?></h2>
                                <p class="text-sm text-gray-600 mb-1">
                                    <span class="font-medium">Category:</span> <?php echo htmlspecialchars($item['category_name']); ?>
                                </p>
                                <p class="text-sm text-gray-600 mb-1">
                                    <span class="font-medium">Type:</span> 
                                    <span class="<?php echo $item['type'] === 'lost' ? 'text-red-600' : 'text-green-600'; ?>">
                                        <?php echo ucfirst($item['type']); ?>
                                    </span>
                                </p>
                                <p class="text-sm text-gray-600 mb-1">
                                    <span class="font-medium">Reported on:</span> <?php echo htmlspecialchars(formatDateTime($item['created_at'])); ?>
                                </p>
                                <p class="text-sm text-gray-600 mb-4">
                                    <span class="font-medium">Status:</span> 
                                    <span class="<?php echo $item['status'] === 'open' ? 'text-blue-600' : 'text-gray-500'; ?>">
                                        <?php echo ucfirst($item['status']); ?>
                                    </span>
                                </p>
                                <a href="item-details.php?id=<?php echo $item['id']; ?>" class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium px-4 py-2 rounded">
                                    View Details
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <?php include('includes/footer.php'); ?>
    <script src="js/app.js"></script>
</body>
</html>
